// Contacts Manager
class ContactsManager {
  constructor() {
    this.contacts = []
    this.init()
  }

  init() {
    this.loadContacts()
    this.setupEventListeners()
    this.renderContacts()
  }

  setupEventListeners() {
    // Add contact button
    document.getElementById("addContactBtn").addEventListener("click", () => {
      this.openAddContactModal()
    })

    // Save contact
    document.getElementById("saveContact").addEventListener("click", () => {
      this.saveContact()
    })

    // Cancel contact
    document.getElementById("cancelContact").addEventListener("click", () => {
      window.ajudaAiApp.closeModal("contactModal")
    })

    // Contact form submission
    document.getElementById("contactForm").addEventListener("submit", (e) => {
      e.preventDefault()
      this.saveContact()
    })
  }

  loadContacts() {
    const stored = localStorage.getItem("ajudaai_contacts")
    this.contacts = stored ? JSON.parse(stored) : this.getDefaultContacts()
  }

  getDefaultContacts() {
    return [
      {
        id: "1",
        name: "Maria Silva",
        phone: "(24) 99999-1234",
        email: "maria@email.com",
        relationship: "Família",
        priority: "high",
      },
      {
        id: "2",
        name: "João Santos",
        phone: "(24) 98888-5678",
        email: "joao@email.com",
        relationship: "Amigo",
        priority: "medium",
      },
    ]
  }

  saveContacts() {
    localStorage.setItem("ajudaai_contacts", JSON.stringify(this.contacts))
  }

  openAddContactModal() {
    // Clear form
    document.getElementById("contactForm").reset()
    window.ajudaAiApp.showModal("contactModal")
  }

  saveContact() {
    const form = document.getElementById("contactForm")
    const formData = new FormData(form)

    const name = document.getElementById("contactName").value.trim()
    const phone = document.getElementById("contactPhone").value.trim()
    const email = document.getElementById("contactEmail").value.trim()
    const relationship = document.getElementById("contactRelationship").value
    const priority = document.getElementById("contactPriority").value

    if (!name || !phone) {
      window.ajudaAiApp.showToast("Erro", "Nome e telefone são obrigatórios", "error")
      return
    }

    const contact = {
      id: Date.now().toString(),
      name,
      phone: window.ajudaAiApp.formatPhone(phone),
      email,
      relationship,
      priority,
    }

    this.contacts.push(contact)
    this.saveContacts()
    this.renderContacts()

    window.ajudaAiApp.closeModal("contactModal")
    window.ajudaAiApp.showToast("Contato Adicionado", `${contact.name} foi adicionado aos seus contatos de emergência`)
  }

  removeContact(id) {
    this.contacts = this.contacts.filter((c) => c.id !== id)
    this.saveContacts()
    this.renderContacts()
    window.ajudaAiApp.showToast("Contato Removido", "Contato removido da lista de emergência")
  }

  renderContacts() {
    const container = document.getElementById("contactsList")

    if (this.contacts.length === 0) {
      container.innerHTML = this.getEmptyState()
      return
    }

    container.innerHTML = this.contacts.map((contact) => this.renderContact(contact)).join("")

    // Add event listeners for contact actions
    this.setupContactActions()
  }

  renderContact(contact) {
    return `
            <div class="contact-item" data-id="${contact.id}">
                <div class="contact-info">
                    <div class="contact-header">
                        <span class="contact-name">${contact.name}</span>
                        <span class="badge priority-${contact.priority}">${this.getPriorityLabel(contact.priority)}</span>
                        <span class="badge relationship">${contact.relationship}</span>
                    </div>
                    <div class="contact-details">
                        <div class="contact-detail">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                            </svg>
                            ${contact.phone}
                        </div>
                        ${
                          contact.email
                            ? `
                            <div class="contact-detail">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                    <polyline points="22,6 12,13 2,6"/>
                                </svg>
                                ${contact.email}
                            </div>
                        `
                            : ""
                        }
                    </div>
                </div>
                <div class="contact-actions">
                    <button class="btn btn-secondary edit-contact" data-id="${contact.id}">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                            <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                        </svg>
                    </button>
                    <button class="btn btn-secondary remove-contact" data-id="${contact.id}">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3,6 5,6 21,6"/>
                            <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"/>
                        </svg>
                    </button>
                </div>
            </div>
        `
  }

  setupContactActions() {
    // Remove contact buttons
    document.querySelectorAll(".remove-contact").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.currentTarget.dataset.id
        if (confirm("Tem certeza que deseja remover este contato?")) {
          this.removeContact(id)
        }
      })
    })

    // Edit contact buttons
    document.querySelectorAll(".edit-contact").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.currentTarget.dataset.id
        this.editContact(id)
      })
    })
  }

  editContact(id) {
    const contact = this.contacts.find((c) => c.id === id)
    if (!contact) return

    // Populate form with contact data
    document.getElementById("contactName").value = contact.name
    document.getElementById("contactPhone").value = contact.phone
    document.getElementById("contactEmail").value = contact.email || ""
    document.getElementById("contactRelationship").value = contact.relationship
    document.getElementById("contactPriority").value = contact.priority

    // Change save button to update
    const saveBtn = document.getElementById("saveContact")
    saveBtn.textContent = "Atualizar"
    saveBtn.onclick = () => this.updateContact(id)

    window.ajudaAiApp.showModal("contactModal")
  }

  updateContact(id) {
    const name = document.getElementById("contactName").value.trim()
    const phone = document.getElementById("contactPhone").value.trim()
    const email = document.getElementById("contactEmail").value.trim()
    const relationship = document.getElementById("contactRelationship").value
    const priority = document.getElementById("contactPriority").value

    if (!name || !phone) {
      window.ajudaAiApp.showToast("Erro", "Nome e telefone são obrigatórios", "error")
      return
    }

    const contactIndex = this.contacts.findIndex((c) => c.id === id)
    if (contactIndex === -1) return

    this.contacts[contactIndex] = {
      ...this.contacts[contactIndex],
      name,
      phone: window.ajudaAiApp.formatPhone(phone),
      email,
      relationship,
      priority,
    }

    this.saveContacts()
    this.renderContacts()

    // Reset save button
    const saveBtn = document.getElementById("saveContact")
    saveBtn.textContent = "Adicionar"
    saveBtn.onclick = () => this.saveContact()

    window.ajudaAiApp.closeModal("contactModal")
    window.ajudaAiApp.showToast("Contato Atualizado", `${name} foi atualizado com sucesso`)
  }

  getPriorityLabel(priority) {
    const labels = {
      high: "Alta",
      medium: "Média",
      low: "Baixa",
    }
    return labels[priority] || "Média"
  }

  getEmptyState() {
    return `
            <div class="empty-state">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                    <circle cx="9" cy="7" r="4"/>
                    <path d="m22 21-3-3m0 0a5.5 5.5 0 1 0-7.78-7.78 5.5 5.5 0 0 0 7.78 7.78Z"/>
                </svg>
                <h3>Nenhum contato de emergência cadastrado</h3>
                <p>Adicione pessoas que devem ser notificadas em caso de emergência</p>
            </div>
        `
  }

  getContactsByPriority(priority) {
    return this.contacts.filter((contact) => contact.priority === priority)
  }

  getContactsByRelationship(relationship) {
    return this.contacts.filter((contact) => contact.relationship === relationship)
  }

  notifyContacts(message, location = null, priority = "all") {
    let contactsToNotify = this.contacts

    if (priority !== "all") {
      contactsToNotify = this.getContactsByPriority(priority)
    }

    contactsToNotify.forEach((contact) => {
      this.sendNotification(contact, message, location)
    })

    return contactsToNotify.length
  }

  sendNotification(contact, message, location) {
    // In a real app, this would send SMS/email/push notification
    console.log(`Sending notification to ${contact.name} (${contact.phone}):`, {
      message,
      location,
      timestamp: new Date(),
    })

    // Simulate notification sending
    setTimeout(() => {
      console.log(`Notification sent to ${contact.name}`)
    }, 1000)
  }
}
