// Emergency Manager
class EmergencyManager {
  constructor() {
    this.emergencyServices = [
      {
        id: "samu",
        name: "SAMU",
        phone: "192",
        description: "Serviço de Atendimento Móvel de Urgência",
      },
      {
        id: "bombeiros",
        name: "Bombeiros",
        phone: "193",
        description: "Corpo de Bombeiros",
      },
      {
        id: "defesa-civil",
        name: "Defesa Civil",
        phone: "199",
        description: "Defesa Civil",
      },
      {
        id: "policia",
        name: "Polícia",
        phone: "190",
        description: "Polícia Militar",
      },
    ]

    this.isEmergencyActive = false
    this.init()
  }

  init() {
    this.setupEventListeners()
  }

  setupEventListeners() {
    // Emergency service buttons
    document.querySelectorAll(".emergency-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const serviceId = e.currentTarget.dataset.service
        this.sendEmergencyAlert(serviceId)
      })
    })

    // Discrete alert button
    document.getElementById("discreteAlert").addEventListener("click", () => {
      this.sendDiscreteAlert()
    })
  }

  async sendEmergencyAlert(serviceId) {
    if (this.isEmergencyActive) return

    const service = this.emergencyServices.find((s) => s.id === serviceId)
    if (!service) return

    // Check location
    const location = await this.getCurrentLocation()
    if (!location) {
      window.ajudaAiApp.showToast("Erro", "Localização não disponível. Tentando obter localização...", "error")
      return
    }

    this.isEmergencyActive = true
    this.showEmergencyOverlay()

    try {
      // Simulate emergency alert sending
      await this.processEmergencyAlert(service, location)

      // Success feedback
      window.ajudaAiApp.vibrate([200, 100, 200, 100, 200])
      window.ajudaAiApp.playSound("success")

      window.ajudaAiApp.showToast(
        "Alerta Enviado!",
        `${service.name} foi notificado da sua localização. Aguarde o atendimento.`,
      )

      // Log emergency
      this.logEmergency(service, location)
    } catch (error) {
      console.error("Emergency alert error:", error)
      window.ajudaAiApp.showToast("Erro", "Falha ao enviar alerta. Tente novamente.", "error")
    } finally {
      setTimeout(() => {
        this.hideEmergencyOverlay()
        this.isEmergencyActive = false
      }, 3000)
    }
  }

  async sendDiscreteAlert() {
    const location = await this.getCurrentLocation()
    if (!location) {
      window.ajudaAiApp.showToast("Erro", "Localização não disponível", "error")
      return
    }

    // Get contacts manager
    const contactsManager = window.ajudaAiApp.contacts
    if (!contactsManager) return

    // Send discrete alert to high priority contacts
    const message = `Preciso de ajuda urgente. Localização: https://www.google.com/maps?q=${location.latitude},${location.longitude}`

    const notifiedCount = contactsManager.notifyContacts(message, location, "high")

    if (notifiedCount > 0) {
      window.ajudaAiApp.vibrate([100])
      window.ajudaAiApp.showToast(
        "Alerta Discreto Enviado",
        `Seus contatos de emergência foram notificados discretamente.`,
      )

      this.logDiscreteAlert(location, notifiedCount)
    } else {
      window.ajudaAiApp.showToast("Erro", "Nenhum contato de alta prioridade encontrado", "error")
    }
  }

  async getCurrentLocation() {
    try {
      if (window.ajudaAiApp.geolocation && window.ajudaAiApp.geolocation.currentPosition) {
        return window.ajudaAiApp.geolocation.currentPosition
      }

      // Try to get fresh location
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 30000,
        })
      })

      return {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: new Date(),
      }
    } catch (error) {
      console.error("Location error:", error)
      return null
    }
  }

  async processEmergencyAlert(service, location) {
    // Simulate API call to emergency services
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log(`Emergency alert sent to ${service.name}:`, {
          service: service.name,
          phone: service.phone,
          location: {
            latitude: location.latitude,
            longitude: location.longitude,
            accuracy: location.accuracy,
          },
          timestamp: new Date(),
          address: `Lat: ${location.latitude.toFixed(6)}, Lng: ${location.longitude.toFixed(6)}`,
        })
        resolve()
      }, 2000)
    })
  }

  showEmergencyOverlay() {
    const overlay = document.getElementById("emergencyOverlay")
    overlay.classList.remove("hidden")
    document.body.style.overflow = "hidden"
  }

  hideEmergencyOverlay() {
    const overlay = document.getElementById("emergencyOverlay")
    overlay.classList.add("hidden")
    document.body.style.overflow = ""
  }

  logEmergency(service, location) {
    const log = {
      type: "emergency",
      service: service.name,
      servicePhone: service.phone,
      location: {
        latitude: location.latitude,
        longitude: location.longitude,
        accuracy: location.accuracy,
      },
      timestamp: new Date(),
      status: "sent",
    }

    this.saveEmergencyLog(log)
  }

  logDiscreteAlert(location, contactsNotified) {
    const log = {
      type: "discrete",
      location: {
        latitude: location.latitude,
        longitude: location.longitude,
        accuracy: location.accuracy,
      },
      contactsNotified,
      timestamp: new Date(),
      status: "sent",
    }

    this.saveEmergencyLog(log)
  }

  saveEmergencyLog(log) {
    const logs = JSON.parse(localStorage.getItem("ajudaai_emergency_logs") || "[]")
    logs.unshift(log)

    // Keep only last 100 logs
    if (logs.length > 100) {
      logs.splice(100)
    }

    localStorage.setItem("ajudaai_emergency_logs", JSON.stringify(logs))
  }

  getEmergencyHistory() {
    return JSON.parse(localStorage.getItem("ajudaai_emergency_logs") || "[]")
  }

  clearEmergencyHistory() {
    localStorage.removeItem("ajudaai_emergency_logs")
    window.ajudaAiApp.showToast("Histórico Limpo", "Histórico de emergências foi removido")
  }

  // Test emergency system
  testEmergencySystem() {
    console.log("Testing emergency system...")

    // Test location
    this.getCurrentLocation().then((location) => {
      if (location) {
        console.log("✓ Location available:", location)
      } else {
        console.log("✗ Location not available")
      }
    })

    // Test contacts
    const contactsManager = window.ajudaAiApp.contacts
    if (contactsManager && contactsManager.contacts.length > 0) {
      console.log("✓ Contacts available:", contactsManager.contacts.length)
    } else {
      console.log("✗ No contacts available")
    }

    // Test alerts
    const alertsManager = window.ajudaAiApp.alerts
    if (alertsManager && alertsManager.alerts.length > 0) {
      console.log("✓ Custom alerts available:", alertsManager.alerts.length)
    } else {
      console.log("✗ No custom alerts available")
    }

    console.log("Emergency system test completed")
  }
}
