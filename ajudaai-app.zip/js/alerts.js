// Alerts Manager
class AlertsManager {
  constructor() {
    this.alerts = []
    this.selectedRecipients = []
    this.init()
  }

  init() {
    this.loadAlerts()
    this.setupEventListeners()
    this.renderAlerts()
  }

  setupEventListeners() {
    // Create alert button
    document.getElementById("createAlertBtn").addEventListener("click", () => {
      this.openCreateAlertModal()
    })

    // Save alert
    document.getElementById("saveAlert").addEventListener("click", () => {
      this.saveAlert()
    })

    // Cancel alert
    document.getElementById("cancelAlert").addEventListener("click", () => {
      window.ajudaAiApp.closeModal("alertModal")
    })

    // Alert form submission
    document.getElementById("alertForm").addEventListener("submit", (e) => {
      e.preventDefault()
      this.saveAlert()
    })

    // Recipient buttons
    document.querySelectorAll(".recipient-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault()
        this.toggleRecipient(e.currentTarget)
      })
    })
  }

  loadAlerts() {
    const stored = localStorage.getItem("ajudaai_alerts")
    this.alerts = stored ? JSON.parse(stored) : this.getDefaultAlerts()
  }

  getDefaultAlerts() {
    return [
      {
        id: "1",
        name: "Assalto Discreto",
        message: "Preciso de ajuda urgente. Localização anexa.",
        isDiscrete: true,
        autoLocation: true,
        delay: 0,
        recipients: ["Família", "Amigos"],
        trigger: "manual",
      },
      {
        id: "2",
        name: "Acidente de Trânsito",
        message: "Sofri um acidente de trânsito. Preciso de ajuda.",
        isDiscrete: false,
        autoLocation: true,
        delay: 30,
        recipients: ["Família"],
        trigger: "manual",
      },
    ]
  }

  saveAlerts() {
    localStorage.setItem("ajudaai_alerts", JSON.stringify(this.alerts))
  }

  openCreateAlertModal() {
    // Clear form
    document.getElementById("alertForm").reset()
    this.selectedRecipients = []
    this.updateRecipientButtons()
    window.ajudaAiApp.showModal("alertModal")
  }

  saveAlert() {
    const name = document.getElementById("alertName").value.trim()
    const message = document.getElementById("alertMessage").value.trim()
    const isDiscrete = document.getElementById("alertDiscrete").checked
    const autoLocation = document.getElementById("alertLocation").checked
    const delay = Number.parseInt(document.getElementById("alertDelay").value)

    if (!name || !message) {
      window.ajudaAiApp.showToast("Erro", "Nome e mensagem são obrigatórios", "error")
      return
    }

    if (this.selectedRecipients.length === 0) {
      window.ajudaAiApp.showToast("Erro", "Selecione pelo menos um grupo de destinatários", "error")
      return
    }

    const alert = {
      id: Date.now().toString(),
      name,
      message,
      isDiscrete,
      autoLocation,
      delay,
      recipients: [...this.selectedRecipients],
      trigger: "manual",
      createdAt: new Date(),
    }

    this.alerts.push(alert)
    this.saveAlerts()
    this.renderAlerts()

    window.ajudaAiApp.closeModal("alertModal")
    window.ajudaAiApp.showToast("Alerta Criado", `Alerta "${alert.name}" foi criado com sucesso`)
  }

  removeAlert(id) {
    this.alerts = this.alerts.filter((a) => a.id !== id)
    this.saveAlerts()
    this.renderAlerts()
    window.ajudaAiApp.showToast("Alerta Removido", "Alerta personalizado foi removido")
  }

  toggleRecipient(button) {
    const recipient = button.dataset.recipient

    if (this.selectedRecipients.includes(recipient)) {
      this.selectedRecipients = this.selectedRecipients.filter((r) => r !== recipient)
      button.classList.remove("active")
    } else {
      this.selectedRecipients.push(recipient)
      button.classList.add("active")
    }
  }

  updateRecipientButtons() {
    document.querySelectorAll(".recipient-btn").forEach((btn) => {
      const recipient = btn.dataset.recipient
      if (this.selectedRecipients.includes(recipient)) {
        btn.classList.add("active")
      } else {
        btn.classList.remove("active")
      }
    })
  }

  renderAlerts() {
    const container = document.getElementById("alertsList")

    if (this.alerts.length === 0) {
      container.innerHTML = this.getEmptyState()
      return
    }

    container.innerHTML = this.alerts.map((alert) => this.renderAlert(alert)).join("")

    // Add event listeners for alert actions
    this.setupAlertActions()
  }

  renderAlert(alert) {
    return `
            <div class="alert-item" data-id="${alert.id}">
                <div class="alert-content">
                    <div class="alert-info">
                        <div class="alert-header">
                            <span class="alert-name">${alert.name}</span>
                            ${alert.isDiscrete ? '<span class="badge">Discreto</span>' : ""}
                            ${alert.autoLocation ? '<span class="badge relationship">Com GPS</span>' : ""}
                            ${alert.delay > 0 ? `<span class="badge relationship">${alert.delay}s</span>` : ""}
                        </div>
                        <p class="alert-message">${alert.message}</p>
                        <div class="alert-recipients">
                            <span>Destinatários:</span>
                            ${alert.recipients
                              .map((recipient) => `<span class="badge relationship">${recipient}</span>`)
                              .join("")}
                        </div>
                    </div>
                    <div class="alert-actions">
                        <button class="btn alert-trigger trigger-alert" data-id="${alert.id}">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/>
                                <path d="M12 9v4"/>
                                <path d="m12 17 .01 0"/>
                            </svg>
                            Ativar
                        </button>
                        <button class="btn btn-secondary edit-alert" data-id="${alert.id}">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                            </svg>
                        </button>
                        <button class="btn btn-secondary remove-alert" data-id="${alert.id}">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3,6 5,6 21,6"/>
                                <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        `
  }

  setupAlertActions() {
    // Trigger alert buttons
    document.querySelectorAll(".trigger-alert").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.currentTarget.dataset.id
        this.triggerAlert(id)
      })
    })

    // Remove alert buttons
    document.querySelectorAll(".remove-alert").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.currentTarget.dataset.id
        if (confirm("Tem certeza que deseja remover este alerta?")) {
          this.removeAlert(id)
        }
      })
    })

    // Edit alert buttons
    document.querySelectorAll(".edit-alert").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.currentTarget.dataset.id
        this.editAlert(id)
      })
    })
  }

  triggerAlert(id) {
    const alert = this.alerts.find((a) => a.id === id)
    if (!alert) return

    // Get current location if needed
    let location = null
    if (alert.autoLocation && window.ajudaAiApp.geolocation) {
      location = window.ajudaAiApp.geolocation.currentPosition
    }

    // Apply delay if specified
    const executeAlert = () => {
      this.executeAlert(alert, location)
    }

    if (alert.delay > 0) {
      window.ajudaAiApp.showToast(
        "Alerta Agendado",
        `"${alert.name}" será enviado em ${alert.delay} segundos`,
        "warning",
      )
      setTimeout(executeAlert, alert.delay * 1000)
    } else {
      executeAlert()
    }
  }

  executeAlert(alert, location) {
    // Get contacts manager
    const contactsManager = window.ajudaAiApp.contacts
    if (!contactsManager) return

    // Build message
    let message = alert.message
    if (location) {
      message += `\n\nLocalização: https://www.google.com/maps?q=${location.latitude},${location.longitude}`
    }

    // Send to selected recipient groups
    let totalNotified = 0
    alert.recipients.forEach((recipientGroup) => {
      const contacts = contactsManager.getContactsByRelationship(recipientGroup)
      contacts.forEach((contact) => {
        contactsManager.sendNotification(contact, message, location)
        totalNotified++
      })
    })

    // Provide feedback
    window.ajudaAiApp.vibrate([200, 100, 200])
    window.ajudaAiApp.playSound("success")

    window.ajudaAiApp.showToast("Alerta Ativado", `"${alert.name}" foi enviado para ${totalNotified} contatos`)

    // Log alert activation
    this.logAlertActivation(alert, location, totalNotified)
  }

  editAlert(id) {
    const alert = this.alerts.find((a) => a.id === id)
    if (!alert) return

    // Populate form with alert data
    document.getElementById("alertName").value = alert.name
    document.getElementById("alertMessage").value = alert.message
    document.getElementById("alertDiscrete").checked = alert.isDiscrete
    document.getElementById("alertLocation").checked = alert.autoLocation
    document.getElementById("alertDelay").value = alert.delay.toString()

    // Set selected recipients
    this.selectedRecipients = [...alert.recipients]
    this.updateRecipientButtons()

    // Change save button to update
    const saveBtn = document.getElementById("saveAlert")
    saveBtn.textContent = "Atualizar"
    saveBtn.onclick = () => this.updateAlert(id)

    window.ajudaAiApp.showModal("alertModal")
  }

  updateAlert(id) {
    const name = document.getElementById("alertName").value.trim()
    const message = document.getElementById("alertMessage").value.trim()
    const isDiscrete = document.getElementById("alertDiscrete").checked
    const autoLocation = document.getElementById("alertLocation").checked
    const delay = Number.parseInt(document.getElementById("alertDelay").value)

    if (!name || !message) {
      window.ajudaAiApp.showToast("Erro", "Nome e mensagem são obrigatórios", "error")
      return
    }

    if (this.selectedRecipients.length === 0) {
      window.ajudaAiApp.showToast("Erro", "Selecione pelo menos um grupo de destinatários", "error")
      return
    }

    const alertIndex = this.alerts.findIndex((a) => a.id === id)
    if (alertIndex === -1) return

    this.alerts[alertIndex] = {
      ...this.alerts[alertIndex],
      name,
      message,
      isDiscrete,
      autoLocation,
      delay,
      recipients: [...this.selectedRecipients],
      updatedAt: new Date(),
    }

    this.saveAlerts()
    this.renderAlerts()

    // Reset save button
    const saveBtn = document.getElementById("saveAlert")
    saveBtn.textContent = "Criar Alerta"
    saveBtn.onclick = () => this.saveAlert()

    window.ajudaAiApp.closeModal("alertModal")
    window.ajudaAiApp.showToast("Alerta Atualizado", `"${name}" foi atualizado com sucesso`)
  }

  logAlertActivation(alert, location, contactsNotified) {
    const log = {
      alertId: alert.id,
      alertName: alert.name,
      timestamp: new Date(),
      location: location
        ? {
            latitude: location.latitude,
            longitude: location.longitude,
          }
        : null,
      contactsNotified,
      recipients: alert.recipients,
    }

    // Store in activation history
    const history = JSON.parse(localStorage.getItem("ajudaai_alert_history") || "[]")
    history.unshift(log)

    // Keep only last 50 activations
    if (history.length > 50) {
      history.splice(50)
    }

    localStorage.setItem("ajudaai_alert_history", JSON.stringify(history))
  }

  getEmptyState() {
    return `
            <div class="empty-state">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                <h3>Nenhum alerta personalizado criado</h3>
                <p>Crie alertas específicos para diferentes situações</p>
            </div>
        `
  }
}
