// TomTom Maps Integration Manager
class TomTomManager {
  constructor(app) {
    this.app = app
    this.map = null
    this.marker = null
    this.accuracyCircle = null
    this.popup = null
    this.watchId = null
    this.isTracking = false
    this.mapLoaded = false
    this.retryCount = 0
    this.maxRetries = 3
    this.trafficVisible = false
    this.currentStyle = "main"

    // TomTom API Key
    this.apiKey = "vnRkpm4mu5sllCR5SrO510AUO2bCFOHuadicione"

    // Map styles available
    this.mapStyles = {
      main: "main",
      satellite: "satellite",
      hybrid: "hybrid",
      night: "night",
    }

    this.currentStyleIndex = 0
    this.styleNames = Object.keys(this.mapStyles)

    // Map configuration
    this.mapConfig = {
      key: this.apiKey,
      container: "map",
      style: "tomtom://vector/1/basic-main",
      zoom: 15,
      center: [-43.1729, -22.9068], // Rio de Janeiro default
      language: "pt-BR",
    }

    this.init()
  }

  init() {
    this.setupEventListeners()
    this.initializeMap()
  }

  setupEventListeners() {
    // Retry button
    document.getElementById("retryMapBtn")?.addEventListener("click", () => {
      this.retryMapLoad()
    })

    // Location request buttons
    document.getElementById("requestLocationBtn")?.addEventListener("click", () => {
      this.requestLocation()
    })

    document.getElementById("useManualLocationBtn")?.addEventListener("click", () => {
      this.showManualLocationSelection()
    })

    // Map control buttons
    document.getElementById("centerLocationBtn")?.addEventListener("click", () => {
      this.centerOnUserLocation()
    })

    document.getElementById("shareLocationBtn")?.addEventListener("click", () => {
      this.shareLocation()
    })

    document.getElementById("fullscreenMapBtn")?.addEventListener("click", () => {
      this.toggleFullscreen()
    })

    document.getElementById("changeMapStyle")?.addEventListener("click", () => {
      this.changeMapStyle()
    })

    document.getElementById("trafficToggle")?.addEventListener("click", () => {
      this.toggleTraffic()
    })

    // Window resize handler
    window.addEventListener(
      "resize",
      this.debounce(() => {
        this.handleResize()
      }, 250),
    )
  }

  async initializeMap() {
    try {
      this.showLoading()

      // Check if TomTom SDK is loaded
      const tt = window.tt // Declare tt variable here
      if (typeof tt === "undefined") {
        throw new Error("TomTom SDK não carregado")
      }

      // Initialize map
      this.map = tt.map(this.mapConfig)

      // Wait for map to load
      this.map.on("load", () => {
        this.onMapLoad()
      })

      this.map.on("error", (error) => {
        console.error("TomTom Map Error:", error)
        this.showError("Erro no Mapa", "Falha ao carregar o mapa TomTom")
      })

      // Add click event
      this.map.on("click", (event) => {
        this.handleMapClick(event.lngLat)
      })

      console.log("TomTom Map inicializado")
    } catch (error) {
      console.error("Failed to initialize TomTom Map:", error)
      this.showError("Falha ao inicializar o mapa", error.message)
    }
  }

  onMapLoad() {
    this.mapLoaded = true
    this.hideLoading()
    this.showMap()

    // Request user location
    this.requestLocation()

    console.log("TomTom Map carregado com sucesso")
  }

  async requestLocation() {
    if (!navigator.geolocation) {
      this.showError("Geolocalização não suportada", "Seu navegador não suporta geolocalização")
      return
    }

    try {
      this.showLocationRequest(false)

      const position = await this.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      })

      await this.updateUserLocation(position)
      this.startLocationTracking()
    } catch (error) {
      console.error("Location request failed:", error)
      this.handleLocationError(error)
    }
  }

  getCurrentPosition(options) {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, options)
    })
  }

  async updateUserLocation(position) {
    const location = {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: position.coords.accuracy,
      timestamp: new Date(position.timestamp),
    }

    // Update app location
    this.app.currentLocation = location

    // Update map
    await this.updateMapLocation(location)

    // Update UI
    this.updateLocationDisplay(location)

    // Get address
    this.reverseGeocode(location.longitude, location.latitude)
  }

  async updateMapLocation(location) {
    if (!this.map) return

    const lngLat = [location.longitude, location.latitude]

    // Update map center
    this.map.setCenter(lngLat)
    this.map.setZoom(16)

    // Update or create marker
    if (this.marker) {
      this.marker.setLngLat(lngLat)
    } else {
      this.createUserMarker(lngLat)
    }

    // Update accuracy circle
    this.updateAccuracyCircle(lngLat, location.accuracy)
  }

  createUserMarker(lngLat) {
    // Create custom marker element
    const markerElement = document.createElement("div")
    markerElement.className = "custom-marker"
    markerElement.innerHTML = `
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
        <circle cx="12" cy="10" r="3" fill="#dc2626"/>
      </svg>
    `

    this.marker = new window.tt.Marker({
      element: markerElement,
      anchor: "bottom",
    })
      .setLngLat(lngLat)
      .addTo(this.map)

    // Add popup
    this.popup = new window.tt.Popup({
      offset: 35,
      closeButton: true,
      closeOnClick: false,
    })

    this.marker.setPopup(this.popup)
  }

  updateAccuracyCircle(lngLat, accuracy) {
    const circleId = "accuracy-circle"

    // Remove existing circle
    if (this.map.getLayer(circleId)) {
      this.map.removeLayer(circleId)
      this.map.removeSource(circleId)
    }

    // Add new circle
    this.map.addSource(circleId, {
      type: "geojson",
      data: {
        type: "Feature",
        geometry: {
          type: "Point",
          coordinates: lngLat,
        },
      },
    })

    this.map.addLayer({
      id: circleId,
      type: "circle",
      source: circleId,
      paint: {
        "circle-radius": {
          stops: [
            [0, 0],
            [20, accuracy * 0.3], // Approximate conversion
          ],
          base: 2,
        },
        "circle-color": "#2563eb",
        "circle-opacity": 0.15,
        "circle-stroke-color": "#2563eb",
        "circle-stroke-width": 2,
        "circle-stroke-opacity": 0.8,
      },
    })
  }

  async reverseGeocode(lng, lat) {
    try {
      const response = await window.tt.services.reverseGeocode({
        key: this.apiKey,
        position: [lng, lat],
        language: "pt-BR",
      })

      if (response.addresses && response.addresses.length > 0) {
        const address = response.addresses[0].address.freeformAddress
        document.getElementById("currentAddress").textContent = address

        // Update popup content
        if (this.popup && this.app.currentLocation) {
          this.updatePopupContent(this.app.currentLocation, address)
        }
      }
    } catch (error) {
      console.warn("Reverse geocoding failed:", error)
      document.getElementById("currentAddress").textContent = "Endereço não disponível"
    }
  }

  updatePopupContent(location, address = "") {
    const content = `
      <div class="popup-content">
        <h4>🚨 Sua Localização Atual</h4>
        ${address ? `<p><strong>Endereço:</strong> ${address}</p>` : ""}
        <p><strong>Coordenadas:</strong> ${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}</p>
        <p><strong>Precisão:</strong> ±${Math.round(location.accuracy)}m</p>
        <p><strong>Atualizado:</strong> ${location.timestamp.toLocaleTimeString()}</p>
        <div class="popup-actions">
          <button onclick="window.ajudaAiApp.tomtomMap.shareLocation()" class="popup-btn">
            Compartilhar
          </button>
          <button onclick="window.ajudaAiApp.tomtomMap.centerOnUserLocation()" class="popup-btn">
            Centralizar
          </button>
        </div>
      </div>
    `

    this.popup.setHTML(content)
  }

  handleMapClick(lngLat) {
    const lat = lngLat.lat
    const lng = lngLat.lng

    // Create temporary marker
    const tempMarkerElement = document.createElement("div")
    tempMarkerElement.className = "temp-marker"
    tempMarkerElement.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
        <circle cx="12" cy="10" r="3" fill="#f59e0b"/>
      </svg>
    `

    const tempMarker = new window.tt.Marker({
      element: tempMarkerElement,
      anchor: "bottom",
    })
      .setLngLat([lng, lat])
      .addTo(this.map)

    // Reverse geocode for clicked location
    this.reverseGeocodeClick(lng, lat, tempMarker)
  }

  async reverseGeocodeClick(lng, lat, tempMarker) {
    try {
      const response = await window.tt.services.reverseGeocode({
        key: this.apiKey,
        position: [lng, lat],
        language: "pt-BR",
      })

      let address = "Endereço não disponível"
      if (response.addresses && response.addresses.length > 0) {
        address = response.addresses[0].address.freeformAddress
      }

      const popup = new window.tt.Popup({
        offset: 35,
        closeButton: true,
        closeOnClick: false,
      }).setHTML(`
        <div class="popup-content">
          <h4>📍 Localização Selecionada</h4>
          <p><strong>Endereço:</strong> ${address}</p>
          <p><strong>Coordenadas:</strong> ${lat.toFixed(6)}, ${lng.toFixed(6)}</p>
          <div class="popup-actions">
            <button onclick="window.ajudaAiApp.tomtomMap.useSelectedLocation(${lat}, ${lng})" class="popup-btn primary">
              Usar Esta Localização
            </button>
            <button onclick="window.ajudaAiApp.tomtomMap.removeTemporaryMarker()" class="popup-btn">
              Cancelar
            </button>
          </div>
        </div>
      `)

      tempMarker.setPopup(popup)
      popup.addTo(this.map)

      // Store temp marker reference
      this.tempMarker = tempMarker
    } catch (error) {
      console.warn("Reverse geocoding failed:", error)
      tempMarker.remove()
    }
  }

  useSelectedLocation(lat, lng) {
    this.app.currentLocation = {
      latitude: lat,
      longitude: lng,
      accuracy: 10,
      timestamp: new Date(),
    }

    this.updateMapLocation(this.app.currentLocation)
    this.updateLocationDisplay(this.app.currentLocation)
    this.removeTemporaryMarker()

    this.app.showToast("Localização Atualizada", "Localização selecionada manualmente foi definida como atual")
  }

  removeTemporaryMarker() {
    if (this.tempMarker) {
      this.tempMarker.remove()
      this.tempMarker = null
    }
  }

  startLocationTracking() {
    if (this.isTracking) return

    this.watchId = navigator.geolocation.watchPosition(
      (position) => {
        this.updateUserLocation(position)
      },
      (error) => {
        console.warn("Location tracking error:", error)
      },
      {
        enableHighAccuracy: true,
        timeout: 30000,
        maximumAge: 10000,
      },
    )

    this.isTracking = true
  }

  stopLocationTracking() {
    if (this.watchId) {
      navigator.geolocation.clearWatch(this.watchId)
      this.watchId = null
      this.isTracking = false
    }
  }

  centerOnUserLocation() {
    if (!this.app.currentLocation || !this.map) {
      this.app.showToast("Erro", "Localização não disponível", "error")
      return
    }

    const lngLat = [this.app.currentLocation.longitude, this.app.currentLocation.latitude]

    this.map.flyTo({
      center: lngLat,
      zoom: 16,
      duration: 1000,
    })

    // Show popup
    if (this.popup && this.marker) {
      this.popup.addTo(this.map)
    }
  }

  shareLocation() {
    if (!this.app.currentLocation) {
      this.app.showToast("Erro", "Localização não disponível", "error")
      return
    }

    const { latitude, longitude } = this.app.currentLocation
    const url = `https://www.google.com/maps?q=${latitude},${longitude}`

    if (navigator.share) {
      navigator
        .share({
          title: "Minha Localização - AjudaAí",
          text: `Estou aqui: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
          url: url,
        })
        .catch(console.error)
    } else {
      // Fallback to clipboard
      navigator.clipboard
        .writeText(url)
        .then(() => {
          this.app.showToast("Link Copiado", "Link da localização copiado para a área de transferência")
        })
        .catch(() => {
          // Fallback to prompt
          prompt("Copie o link da sua localização:", url)
        })
    }
  }

  changeMapStyle() {
    if (!this.map) return

    this.currentStyleIndex = (this.currentStyleIndex + 1) % this.styleNames.length
    const newStyle = this.styleNames[this.currentStyleIndex]

    let styleUrl
    switch (newStyle) {
      case "satellite":
        styleUrl = "tomtom://vector/1/basic-satellite"
        break
      case "hybrid":
        styleUrl = "tomtom://vector/1/hybrid-main"
        break
      case "night":
        styleUrl = "tomtom://vector/1/basic-night"
        break
      default:
        styleUrl = "tomtom://vector/1/basic-main"
    }

    this.map.setStyle(styleUrl)
    this.currentStyle = newStyle

    const styleNames = {
      main: "Padrão",
      satellite: "Satélite",
      hybrid: "Híbrido",
      night: "Noturno",
    }

    this.app.showToast("Estilo Alterado", `Mapa alterado para: ${styleNames[newStyle]}`)
  }

  toggleTraffic() {
    if (!this.map) return

    this.trafficVisible = !this.trafficVisible

    if (this.trafficVisible) {
      // Add traffic layer
      this.map.addSource("traffic", {
        type: "vector",
        url: `https://api.tomtom.com/traffic/map/4/tile/flow/absolute/{z}/{x}/{y}.pbf?key=${this.apiKey}`,
      })

      this.map.addLayer({
        id: "traffic-flow",
        type: "line",
        source: "traffic",
        "source-layer": "traffic",
        paint: {
          "line-color": [
            "case",
            ["<", ["get", "speed"], 30],
            "#ff0000",
            ["<", ["get", "speed"], 60],
            "#ffaa00",
            "#00ff00",
          ],
          "line-width": 3,
          "line-opacity": 0.8,
        },
      })

      this.app.showToast("Trânsito Ativado", "Informações de trânsito em tempo real ativadas")
    } else {
      // Remove traffic layer
      if (this.map.getLayer("traffic-flow")) {
        this.map.removeLayer("traffic-flow")
        this.map.removeSource("traffic")
      }

      this.app.showToast("Trânsito Desativado", "Informações de trânsito removidas do mapa")
    }
  }

  toggleFullscreen() {
    const mapContainer = document.getElementById("mapContainer")

    if (!document.fullscreenElement) {
      mapContainer
        .requestFullscreen()
        .then(() => {
          mapContainer.classList.add("fullscreen")
          this.handleResize()
        })
        .catch(console.error)
    } else {
      document
        .exitFullscreen()
        .then(() => {
          mapContainer.classList.remove("fullscreen")
          this.handleResize()
        })
        .catch(console.error)
    }
  }

  handleResize() {
    if (this.map) {
      this.map.resize()
      if (this.app.currentLocation) {
        setTimeout(() => {
          this.centerOnUserLocation()
        }, 100)
      }
    }
  }

  handleLocationError(error) {
    let title = "Erro de Localização"
    let message = "Não foi possível obter sua localização"

    switch (error.code) {
      case error.PERMISSION_DENIED:
        title = "Permissão Negada"
        message =
          'Você negou o acesso à localização. Clique em "Selecionar Manualmente" para escolher sua localização no mapa.'
        break
      case error.POSITION_UNAVAILABLE:
        title = "Localização Indisponível"
        message = "Informações de localização não estão disponíveis no momento."
        break
      case error.TIMEOUT:
        title = "Tempo Esgotado"
        message = "A solicitação de localização expirou. Tente novamente."
        break
    }

    this.showLocationRequest(true)
    this.app.showToast(title, message, "error")
  }

  retryMapLoad() {
    if (this.retryCount < this.maxRetries) {
      this.retryCount++
      this.hideError()
      this.initializeMap()
    } else {
      this.showError("Falha Permanente", "Não foi possível carregar o mapa após várias tentativas")
    }
  }

  showManualLocationSelection() {
    this.hideLocationRequest()
    this.showMap()

    if (!this.map) {
      this.initializeMap()
    }

    this.app.showToast("Seleção Manual", "Clique no mapa para selecionar sua localização")
  }

  updateLocationDisplay(location) {
    document.getElementById("currentLat").textContent = location.latitude.toFixed(6)
    document.getElementById("currentLng").textContent = location.longitude.toFixed(6)
    document.getElementById("currentAccuracy").textContent = `±${Math.round(location.accuracy)}m`
    document.getElementById("lastUpdate").textContent = location.timestamp.toLocaleTimeString()

    document.getElementById("locationInfoPanel").classList.remove("hidden")
  }

  // UI State Management
  showLoading() {
    document.getElementById("mapLoading").classList.remove("hidden")
    this.hideError()
    this.hideLocationRequest()
    this.hideMap()
  }

  hideLoading() {
    document.getElementById("mapLoading").classList.add("hidden")
  }

  showError(title, message) {
    document.getElementById("errorTitle").textContent = title
    document.getElementById("errorMessage").textContent = message
    document.getElementById("mapError").classList.remove("hidden")
    this.hideLoading()
    this.hideLocationRequest()
    this.hideMap()
  }

  hideError() {
    document.getElementById("mapError").classList.add("hidden")
  }

  showLocationRequest(showManualOption = true) {
    document.getElementById("locationRequest").classList.remove("hidden")
    document.getElementById("useManualLocationBtn").style.display = showManualOption ? "block" : "none"
    this.hideLoading()
    this.hideError()
    this.hideMap()
  }

  hideLocationRequest() {
    document.getElementById("locationRequest").classList.add("hidden")
  }

  showMap() {
    document.getElementById("map").classList.remove("hidden")
    document.getElementById("mapControls").classList.remove("hidden")
  }

  hideMap() {
    document.getElementById("map").classList.add("hidden")
    document.getElementById("mapControls").classList.add("hidden")
  }

  // Utility function
  debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
    }
  }

  // Cleanup
  destroy() {
    this.stopLocationTracking()
    this.removeTemporaryMarker()

    if (this.map) {
      this.map.remove()
      this.map = null
    }
  }
}

// Export for use in main app
window.TomTomManager = TomTomManager
