// Landmark Selection Manager - Web equivalent of Android LandmarkSelectionActivity
class LandmarkSelectionManager {
  constructor(app, googleMaps) {
    this.app = app
    this.googleMaps = googleMaps
    this.placesService = null
    this.landmarks = []
    this.landmarkMarkers = []
    this.userMarker = null
    this.selectedLandmark = null
    this.isLandmarkMode = false

    // Landmark types to search for
    this.landmarkTypes = [
      "hospital",
      "police",
      "fire_station",
      "school",
      "university",
      "church",
      "mosque",
      "synagogue",
      "park",
      "shopping_mall",
      "gas_station",
      "bank",
      "pharmacy",
      "restaurant",
      "tourist_attraction",
      "government",
    ]

    this.init()
  }

  init() {
    this.setupEventListeners()
  }

  setupEventListeners() {
    // Landmark selection button
    document.getElementById("selectLandmarkBtn")?.addEventListener("click", () => {
      this.toggleLandmarkMode()
    })

    // Close landmark panel
    document.getElementById("closeLandmarkPanel")?.addEventListener("click", () => {
      this.closeLandmarkPanel()
    })

    // Search landmarks
    document.getElementById("searchLandmarks")?.addEventListener("click", () => {
      this.searchLandmarks()
    })

    // Search on Enter key
    document.getElementById("landmarkSearch")?.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        this.searchLandmarks()
      }
    })
  }

  // Initialize Places Service when map is ready
  initializePlacesService() {
    if (this.googleMaps.map && window.google?.maps?.places) {
      this.placesService = new window.google.maps.places.PlacesService(this.googleMaps.map)
      console.log("Places Service initialized")
    }
  }

  toggleLandmarkMode() {
    if (!this.isLandmarkMode) {
      this.enterLandmarkMode()
    } else {
      this.exitLandmarkMode()
    }
  }

  enterLandmarkMode() {
    this.isLandmarkMode = true

    // Initialize Places Service if not already done
    if (!this.placesService) {
      this.initializePlacesService()
    }

    // Show landmark panel
    this.showLandmarkPanel()

    // Search for nearby landmarks
    this.searchNearbyLandmarks()

    // Update button state
    document.getElementById("selectLandmarkBtn")?.classList.add("active")

    this.app.showToast("Modo Landmark", "Selecione um ponto de referência no mapa ou na lista")
  }

  exitLandmarkMode() {
    this.isLandmarkMode = false

    // Hide landmark panel
    this.closeLandmarkPanel()

    // Clear landmark markers
    this.clearLandmarkMarkers()

    // Update button state
    document.getElementById("selectLandmarkBtn")?.classList.remove("active")
  }

  showLandmarkPanel() {
    document.getElementById("landmarkPanel")?.classList.remove("hidden")
  }

  closeLandmarkPanel() {
    document.getElementById("landmarkPanel")?.classList.add("hidden")
    this.exitLandmarkMode()
  }

  async searchNearbyLandmarks() {
    if (!this.placesService || !this.app.currentLocation) {
      this.app.showToast("Erro", "Localização não disponível para buscar landmarks", "error")
      return
    }

    const location = new window.google.maps.LatLng(
      this.app.currentLocation.latitude,
      this.app.currentLocation.longitude,
    )

    const request = {
      location: location,
      radius: 2000, // 2km radius
      types: this.landmarkTypes,
    }

    try {
      const results = await this.performNearbySearch(request)
      this.displayLandmarks(results)
      this.createLandmarkMarkers(results)
    } catch (error) {
      console.error("Error searching landmarks:", error)
      this.app.showToast("Erro", "Falha ao buscar pontos de referência", "error")
    }
  }

  performNearbySearch(request) {
    return new Promise((resolve, reject) => {
      this.placesService.nearbySearch(request, (results, status) => {
        if (status === window.google.maps.places.PlacesServiceStatus.OK) {
          resolve(results)
        } else {
          reject(new Error(`Places search failed: ${status}`))
        }
      })
    })
  }

  async searchLandmarks() {
    const query = document.getElementById("landmarkSearch")?.value.trim()
    if (!query || !this.placesService || !this.app.currentLocation) {
      return
    }

    const location = new window.google.maps.LatLng(
      this.app.currentLocation.latitude,
      this.app.currentLocation.longitude,
    )

    const request = {
      location: location,
      radius: 5000, // 5km radius for text search
      query: query,
    }

    try {
      const results = await this.performTextSearch(request)
      this.displayLandmarks(results)
      this.createLandmarkMarkers(results)
    } catch (error) {
      console.error("Error searching landmarks:", error)
      this.app.showToast("Erro", "Falha na busca de landmarks", "error")
    }
  }

  performTextSearch(request) {
    return new Promise((resolve, reject) => {
      this.placesService.textSearch(request, (results, status) => {
        if (status === window.google.maps.places.PlacesServiceStatus.OK) {
          resolve(results)
        } else {
          reject(new Error(`Text search failed: ${status}`))
        }
      })
    })
  }

  displayLandmarks(landmarks) {
    this.landmarks = landmarks
    const container = document.getElementById("landmarksList")

    if (!container) return

    if (landmarks.length === 0) {
      container.innerHTML = `
        <div class="no-landmarks">
          <p>Nenhum ponto de referência encontrado</p>
        </div>
      `
      return
    }

    container.innerHTML = landmarks.map((landmark, index) => this.renderLandmarkItem(landmark, index)).join("")

    // Add click listeners
    container.querySelectorAll(".landmark-item").forEach((item, index) => {
      item.addEventListener("click", () => {
        this.selectLandmark(landmarks[index])
      })
    })
  }

  renderLandmarkItem(landmark, index) {
    const distance = this.calculateDistance(landmark.geometry.location)
    const rating = landmark.rating ? `⭐ ${landmark.rating.toFixed(1)}` : ""
    const isOpen = landmark.opening_hours?.open_now ? "🟢 Aberto" : landmark.opening_hours ? "🔴 Fechado" : ""

    return `
      <div class="landmark-item" data-index="${index}">
        <div class="landmark-info">
          <h4 class="landmark-name">${landmark.name}</h4>
          <p class="landmark-address">${landmark.vicinity || landmark.formatted_address || ""}</p>
          <div class="landmark-details">
            <span class="landmark-distance">${distance}</span>
            ${rating ? `<span class="landmark-rating">${rating}</span>` : ""}
            ${isOpen ? `<span class="landmark-status">${isOpen}</span>` : ""}
          </div>
          <div class="landmark-types">
            ${landmark.types
              .slice(0, 3)
              .map((type) => `<span class="landmark-type">${this.formatType(type)}</span>`)
              .join("")}
          </div>
        </div>
        <div class="landmark-actions">
          <button class="select-landmark-btn" title="Selecionar este landmark">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="20,6 9,17 4,12"/>
            </svg>
          </button>
        </div>
      </div>
    `
  }

  calculateDistance(location) {
    if (!this.app.currentLocation) return "N/A"

    const userLatLng = new window.google.maps.LatLng(
      this.app.currentLocation.latitude,
      this.app.currentLocation.longitude,
    )

    const distance = window.google.maps.geometry.spherical.computeDistanceBetween(userLatLng, location)

    if (distance < 1000) {
      return `${Math.round(distance)}m`
    } else {
      return `${(distance / 1000).toFixed(1)}km`
    }
  }

  formatType(type) {
    const typeMap = {
      hospital: "Hospital",
      police: "Polícia",
      fire_station: "Bombeiros",
      school: "Escola",
      university: "Universidade",
      church: "Igreja",
      mosque: "Mesquita",
      synagogue: "Sinagoga",
      park: "Parque",
      shopping_mall: "Shopping",
      gas_station: "Posto",
      bank: "Banco",
      pharmacy: "Farmácia",
      restaurant: "Restaurante",
      tourist_attraction: "Atração",
      government: "Governo",
    }

    return typeMap[type] || type.replace(/_/g, " ")
  }

  createLandmarkMarkers(landmarks) {
    // Clear existing markers
    this.clearLandmarkMarkers()

    landmarks.forEach((landmark, index) => {
      const marker = new window.google.maps.Marker({
        position: landmark.geometry.location,
        map: this.googleMaps.map,
        title: landmark.name,
        icon: {
          url: this.getLandmarkIcon(landmark.types[0]),
          scaledSize: new window.google.maps.Size(24, 24),
          anchor: new window.google.maps.Point(12, 24),
        },
      })

      // Create info window
      const infoWindow = new window.google.maps.InfoWindow({
        content: this.createLandmarkInfoWindow(landmark),
      })

      marker.addListener("click", () => {
        // Close other info windows
        this.landmarkMarkers.forEach((m) => {
          if (m.infoWindow) {
            m.infoWindow.close()
          }
        })

        infoWindow.open(this.googleMaps.map, marker)
      })

      marker.infoWindow = infoWindow
      this.landmarkMarkers.push(marker)
    })
  }

  getLandmarkIcon(type) {
    const iconMap = {
      hospital: "🏥",
      police: "👮",
      fire_station: "🚒",
      school: "🏫",
      university: "🎓",
      church: "⛪",
      mosque: "🕌",
      synagogue: "🕍",
      park: "🌳",
      shopping_mall: "🛒",
      gas_station: "⛽",
      bank: "🏦",
      pharmacy: "💊",
      restaurant: "🍽️",
      tourist_attraction: "🎯",
      government: "🏛️",
    }

    const emoji = iconMap[type] || "📍"

    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="10" fill="#ffffff" stroke="#2563eb" stroke-width="2"/>
        <text x="12" y="16" text-anchor="middle" font-size="12">${emoji}</text>
      </svg>
    `

    return "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(svg)
  }

  createLandmarkInfoWindow(landmark) {
    const distance = this.calculateDistance(landmark.geometry.location)
    const rating = landmark.rating ? `⭐ ${landmark.rating.toFixed(1)}` : ""
    const isOpen = landmark.opening_hours?.open_now ? "🟢 Aberto agora" : landmark.opening_hours ? "🔴 Fechado" : ""

    return `
      <div class="landmark-info-window">
        <h4>${landmark.name}</h4>
        <p>${landmark.vicinity || landmark.formatted_address || ""}</p>
        <div class="landmark-meta">
          <span>📍 ${distance}</span>
          ${rating ? `<span>${rating}</span>` : ""}
          ${isOpen ? `<span>${isOpen}</span>` : ""}
        </div>
        <div class="landmark-actions">
          <button onclick="window.ajudaAiApp.landmarkSelection.selectLandmark(${JSON.stringify(landmark).replace(/"/g, "&quot;")})" 
                  class="select-btn">
            Selecionar como Referência
          </button>
          <button onclick="window.ajudaAiApp.landmarkSelection.navigateToLandmark(${landmark.geometry.location.lat()}, ${landmark.geometry.location.lng()})" 
                  class="navigate-btn">
            Como Chegar
          </button>
        </div>
      </div>
    `
  }

  selectLandmark(landmark) {
    this.selectedLandmark = landmark

    // Update user location to landmark location
    const landmarkLocation = {
      latitude: landmark.geometry.location.lat(),
      longitude: landmark.geometry.location.lng(),
      accuracy: 10,
      timestamp: new Date(),
      landmark: {
        name: landmark.name,
        address: landmark.vicinity || landmark.formatted_address,
        placeId: landmark.place_id,
      },
    }

    this.app.currentLocation = landmarkLocation

    // Update map
    this.googleMaps.updateMapLocation(landmarkLocation)

    // Close landmark panel
    this.closeLandmarkPanel()

    // Show success message
    this.app.showToast("Landmark Selecionado", `"${landmark.name}" definido como sua localização de referência`)

    // Log landmark selection
    this.logLandmarkSelection(landmark)
  }

  navigateToLandmark(lat, lng) {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`
    window.open(url, "_blank")
  }

  clearLandmarkMarkers() {
    this.landmarkMarkers.forEach((marker) => {
      if (marker.infoWindow) {
        marker.infoWindow.close()
      }
      marker.setMap(null)
    })
    this.landmarkMarkers = []
  }

  logLandmarkSelection(landmark) {
    const log = {
      type: "landmark_selection",
      landmark: {
        name: landmark.name,
        placeId: landmark.place_id,
        location: {
          latitude: landmark.geometry.location.lat(),
          longitude: landmark.geometry.location.lng(),
        },
        address: landmark.vicinity || landmark.formatted_address,
        types: landmark.types,
      },
      timestamp: new Date(),
      userLocation: this.app.currentLocation,
    }

    const logs = JSON.parse(localStorage.getItem("ajudaai_landmark_logs") || "[]")
    logs.unshift(log)

    // Keep only last 50 selections
    if (logs.length > 50) {
      logs.splice(50)
    }

    localStorage.setItem("ajudaai_landmark_logs", JSON.stringify(logs))
  }

  // Get recently selected landmarks
  getRecentLandmarks() {
    const logs = JSON.parse(localStorage.getItem("ajudaai_landmark_logs") || "[]")
    return logs.slice(0, 10) // Return last 10 selections
  }

  // Cleanup
  destroy() {
    this.clearLandmarkMarkers()
    this.selectedLandmark = null
    this.landmarks = []
  }
}

// Export for use in main app
window.LandmarkSelectionManager = LandmarkSelectionManager
