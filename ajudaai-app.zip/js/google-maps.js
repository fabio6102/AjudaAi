// Google Maps Integration Module
class GoogleMapsManager {
  constructor(app) {
    this.app = app
    this.map = null
    this.marker = null
    this.accuracyCircle = null
    this.geocoder = null
    this.infoWindow = null
    this.watchId = null
    this.isTracking = false
    this.mapLoaded = false
    this.retryCount = 0
    this.maxRetries = 3

    // Map configuration
    this.mapConfig = {
      zoom: 16,
      minZoom: 10,
      maxZoom: 20,
      mapTypeId: "roadmap",
      disableDefaultUI: false,
      zoomControl: true,
      streetViewControl: true,
      fullscreenControl: false, // We'll use custom control
      mapTypeControl: true,
      gestureHandling: "cooperative",
      styles: this.getMapStyles(),
    }

    this.init()
  }

  init() {
    this.setupEventListeners()
    this.checkGoogleMapsAPI()
  }

  setupEventListeners() {
    // Retry button
    document.getElementById("retryMapBtn")?.addEventListener("click", () => {
      this.retryMapLoad()
    })

    // Location request buttons
    document.getElementById("requestLocationBtn")?.addEventListener("click", () => {
      this.requestLocation()
    })

    document.getElementById("useManualLocationBtn")?.addEventListener("click", () => {
      this.showManualLocationSelection()
    })

    // Map control buttons
    document.getElementById("centerLocationBtn")?.addEventListener("click", () => {
      this.centerOnUserLocation()
    })

    document.getElementById("shareLocationBtn")?.addEventListener("click", () => {
      this.shareLocation()
    })

    document.getElementById("fullscreenMapBtn")?.addEventListener("click", () => {
      this.toggleFullscreen()
    })

    // Window resize handler for responsive design
    window.addEventListener(
      "resize",
      this.debounce(() => {
        this.handleResize()
      }, 250),
    )
  }

  checkGoogleMapsAPI() {
    if (typeof window.google !== "undefined" && window.google.maps) {
      this.initializeMap()
    } else {
      // Wait for Google Maps API to load
      window.initMap = () => {
        this.initializeMap()
      }
    }
  }

  async initializeMap() {
    try {
      this.showLoading()

      // Initialize map
      await this.createMap()

      // Initialize geocoder
      this.geocoder = new window.google.maps.Geocoder()

      // Initialize info window
      this.infoWindow = new window.google.maps.InfoWindow()

      // Request user location
      await this.requestLocation()

      this.mapLoaded = true
      this.hideLoading()
      this.showMap()

      console.log("Google Maps initialized successfully")
    } catch (error) {
      console.error("Failed to initialize Google Maps:", error)
      this.showError("Falha ao inicializar o mapa", error.message)
    }
  }

  async createMap() {
    const mapElement = document.getElementById("map")
    if (!mapElement) {
      throw new Error("Map container not found")
    }

    // Default center (Brazil)
    const defaultCenter = { lat: -22.9068, lng: -43.1729 }

    this.map = new window.google.maps.Map(mapElement, {
      ...this.mapConfig,
      center: defaultCenter,
    })

    // Add map event listeners
    this.map.addListener("click", (event) => {
      this.handleMapClick(event.latLng)
    })

    this.map.addListener("idle", () => {
      this.onMapIdle()
    })

    // Add custom controls
    this.addCustomControls()
  }

  addCustomControls() {
    // Create custom control container
    const controlsContainer = document.getElementById("mapControls")
    if (controlsContainer) {
      controlsContainer.classList.remove("hidden")
    }
  }

  async requestLocation() {
    if (!navigator.geolocation) {
      this.showError("Geolocalização não suportada", "Seu navegador não suporta geolocalização")
      return
    }

    try {
      this.showLocationRequest(false)

      const position = await this.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      })

      await this.updateUserLocation(position)
      this.startLocationTracking()
    } catch (error) {
      console.error("Location request failed:", error)
      this.handleLocationError(error)
    }
  }

  getCurrentPosition(options) {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, options)
    })
  }

  async updateUserLocation(position) {
    const location = {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: position.coords.accuracy,
      timestamp: new Date(position.timestamp),
    }

    // Update app location
    this.app.currentLocation = location

    // Update map
    await this.updateMapLocation(location)

    // Update UI
    this.updateLocationDisplay(location)

    // Update status
    this.app.updateLocationStatus(position)
  }

  async updateMapLocation(location) {
    if (!this.map) return

    const position = {
      lat: location.latitude,
      lng: location.longitude,
    }

    // Update map center
    this.map.setCenter(position)
    this.map.setZoom(16)

    // Update or create marker
    if (this.marker) {
      this.marker.setPosition(position)
    } else {
      this.createUserMarker(position)
    }

    // Update accuracy circle
    this.updateAccuracyCircle(position, location.accuracy)

    // Reverse geocode to get address
    try {
      const address = await this.reverseGeocode(position)
      this.updateInfoWindow(location, address)
    } catch (error) {
      console.warn("Reverse geocoding failed:", error)
    }
  }

  createUserMarker(position) {
    this.marker = new window.google.maps.Marker({
      position: position,
      map: this.map,
      title: "Sua Localização Atual",
      icon: {
        url: this.createMarkerIcon(),
        scaledSize: new window.google.maps.Size(32, 32),
        anchor: new window.google.maps.Point(16, 32),
      },
      animation: window.google.maps.Animation.DROP,
    })

    // Add click listener
    this.marker.addListener("click", () => {
      this.infoWindow.open(this.map, this.marker)
    })
  }

  createMarkerIcon() {
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
        <circle cx="12" cy="10" r="3" fill="#dc2626"/>
      </svg>
    `
    return "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(svg)
  }

  updateAccuracyCircle(position, accuracy) {
    if (this.accuracyCircle) {
      this.accuracyCircle.setMap(null)
    }

    this.accuracyCircle = new window.google.maps.Circle({
      strokeColor: "#2563eb",
      strokeOpacity: 0.8,
      strokeWeight: 2,
      fillColor: "#2563eb",
      fillOpacity: 0.15,
      map: this.map,
      center: position,
      radius: accuracy,
    })
  }

  async reverseGeocode(position) {
    return new Promise((resolve, reject) => {
      this.geocoder.geocode({ location: position }, (results, status) => {
        if (status === "OK" && results[0]) {
          resolve(results[0].formatted_address)
        } else {
          reject(new Error("Geocoding failed: " + status))
        }
      })
    })
  }

  updateInfoWindow(location, address = "") {
    const content = `
      <div class="info-window">
        <h4>🚨 Sua Localização Atual</h4>
        ${address ? `<p><strong>Endereço:</strong> ${address}</p>` : ""}
        <p><strong>Coordenadas:</strong> ${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}</p>
        <p><strong>Precisão:</strong> ±${Math.round(location.accuracy)}m</p>
        <p><strong>Atualizado:</strong> ${location.timestamp.toLocaleTimeString()}</p>
        <div class="info-actions">
          <button onclick="window.ajudaAiApp.googleMaps.shareLocation()" class="info-btn">
            Compartilhar
          </button>
          <button onclick="window.ajudaAiApp.googleMaps.centerOnUserLocation()" class="info-btn">
            Centralizar
          </button>
        </div>
      </div>
    `

    this.infoWindow.setContent(content)
  }

  startLocationTracking() {
    if (this.isTracking) return

    this.watchId = navigator.geolocation.watchPosition(
      (position) => {
        this.updateUserLocation(position)
      },
      (error) => {
        console.warn("Location tracking error:", error)
      },
      {
        enableHighAccuracy: true,
        timeout: 30000,
        maximumAge: 10000,
      },
    )

    this.isTracking = true
  }

  stopLocationTracking() {
    if (this.watchId) {
      navigator.geolocation.clearWatch(this.watchId)
      this.watchId = null
      this.isTracking = false
    }
  }

  handleMapClick(latLng) {
    const lat = latLng.lat()
    const lng = latLng.lng()

    // Create temporary marker
    const tempMarker = new window.google.maps.Marker({
      position: latLng,
      map: this.map,
      title: "Localização Selecionada",
      icon: {
        url: this.createTempMarkerIcon(),
        scaledSize: new window.google.maps.Size(24, 24),
        anchor: new window.google.maps.Point(12, 24),
      },
    })

    // Reverse geocode
    this.reverseGeocode(latLng)
      .then((address) => {
        const infoWindow = new window.google.maps.InfoWindow({
          content: `
            <div class="info-window">
              <h4>📍 Localização Selecionada</h4>
              <p><strong>Endereço:</strong> ${address}</p>
              <p><strong>Coordenadas:</strong> ${lat.toFixed(6)}, ${lng.toFixed(6)}</p>
              <div class="info-actions">
                <button onclick="window.ajudaAiApp.googleMaps.useSelectedLocation(${lat}, ${lng}, '${tempMarker.getPosition().toString()}')" class="info-btn primary">
                  Usar Esta Localização
                </button>
                <button onclick="window.ajudaAiApp.googleMaps.removeTemporaryMarker('${tempMarker.getPosition().toString()}')" class="info-btn">
                  Cancelar
                </button>
              </div>
            </div>
          `,
        })

        infoWindow.open(this.map, tempMarker)

        // Store temp marker reference
        tempMarker.infoWindow = infoWindow
        this.tempMarkers = this.tempMarkers || []
        this.tempMarkers.push(tempMarker)
      })
      .catch(() => {
        tempMarker.setMap(null)
      })
  }

  createTempMarkerIcon() {
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
        <circle cx="12" cy="10" r="3" fill="#f59e0b"/>
      </svg>
    `
    return "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(svg)
  }

  useSelectedLocation(lat, lng, markerId) {
    this.app.currentLocation = {
      latitude: lat,
      longitude: lng,
      accuracy: 10,
      timestamp: new Date(),
    }

    this.updateMapLocation(this.app.currentLocation)
    this.updateLocationDisplay(this.app.currentLocation)
    this.clearTemporaryMarkers()

    this.app.showToast("Localização Atualizada", "Localização selecionada manualmente foi definida como atual")
  }

  removeTemporaryMarker(markerId) {
    this.clearTemporaryMarkers()
  }

  clearTemporaryMarkers() {
    if (this.tempMarkers) {
      this.tempMarkers.forEach((marker) => {
        if (marker.infoWindow) {
          marker.infoWindow.close()
        }
        marker.setMap(null)
      })
      this.tempMarkers = []
    }
  }

  centerOnUserLocation() {
    if (!this.app.currentLocation || !this.map) {
      this.app.showToast("Erro", "Localização não disponível", "error")
      return
    }

    const position = {
      lat: this.app.currentLocation.latitude,
      lng: this.app.currentLocation.longitude,
    }

    this.map.setCenter(position)
    this.map.setZoom(16)

    // Bounce marker
    if (this.marker) {
      this.marker.setAnimation(window.google.maps.Animation.BOUNCE)
      setTimeout(() => {
        this.marker.setAnimation(null)
      }, 2000)
    }
  }

  shareLocation() {
    if (!this.app.currentLocation) {
      this.app.showToast("Erro", "Localização não disponível", "error")
      return
    }

    const { latitude, longitude } = this.app.currentLocation
    const url = `https://www.google.com/maps?q=${latitude},${longitude}`

    if (navigator.share) {
      navigator
        .share({
          title: "Minha Localização - AjudaAí",
          text: `Estou aqui: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
          url: url,
        })
        .catch(console.error)
    } else {
      // Fallback to clipboard
      navigator.clipboard
        .writeText(url)
        .then(() => {
          this.app.showToast("Link Copiado", "Link da localização copiado para a área de transferência")
        })
        .catch(() => {
          // Fallback to prompt
          prompt("Copie o link da sua localização:", url)
        })
    }
  }

  toggleFullscreen() {
    const mapContainer = document.getElementById("mapContainer")

    if (!document.fullscreenElement) {
      mapContainer
        .requestFullscreen()
        .then(() => {
          mapContainer.classList.add("fullscreen")
          this.handleResize()
        })
        .catch(console.error)
    } else {
      document
        .exitFullscreen()
        .then(() => {
          mapContainer.classList.remove("fullscreen")
          this.handleResize()
        })
        .catch(console.error)
    }
  }

  handleResize() {
    if (this.map) {
      window.google.maps.event.trigger(this.map, "resize")
      if (this.app.currentLocation) {
        this.centerOnUserLocation()
      }
    }
  }

  onMapIdle() {
    // Map finished loading/moving
    this.hideLoading()
  }

  handleLocationError(error) {
    let title = "Erro de Localização"
    let message = "Não foi possível obter sua localização"

    switch (error.code) {
      case error.PERMISSION_DENIED:
        title = "Permissão Negada"
        message =
          'Você negou o acesso à localização. Clique em "Selecionar Manualmente" para escolher sua localização no mapa.'
        break
      case error.POSITION_UNAVAILABLE:
        title = "Localização Indisponível"
        message = "Informações de localização não estão disponíveis no momento."
        break
      case error.TIMEOUT:
        title = "Tempo Esgotado"
        message = "A solicitação de localização expirou. Tente novamente."
        break
    }

    this.showLocationRequest(true)
    this.app.showToast(title, message, "error")
  }

  retryMapLoad() {
    if (this.retryCount < this.maxRetries) {
      this.retryCount++
      this.hideError()
      this.initializeMap()
    } else {
      this.showError("Falha Permanente", "Não foi possível carregar o mapa após várias tentativas")
    }
  }

  showManualLocationSelection() {
    this.hideLocationRequest()
    this.showMap()

    if (!this.map) {
      this.createMap()
    }

    this.app.showToast("Seleção Manual", "Clique no mapa para selecionar sua localização")
  }

  updateLocationDisplay(location) {
    document.getElementById("currentLat").textContent = location.latitude.toFixed(6)
    document.getElementById("currentLng").textContent = location.longitude.toFixed(6)
    document.getElementById("currentAccuracy").textContent = `±${Math.round(location.accuracy)}m`
    document.getElementById("lastUpdate").textContent = location.timestamp.toLocaleTimeString()

    document.getElementById("locationInfoPanel").classList.remove("hidden")
  }

  getMapStyles() {
    return [
      {
        featureType: "poi",
        elementType: "labels",
        stylers: [{ visibility: "off" }],
      },
      {
        featureType: "transit",
        elementType: "labels",
        stylers: [{ visibility: "off" }],
      },
    ]
  }

  // UI State Management
  showLoading() {
    document.getElementById("mapLoading").classList.remove("hidden")
    this.hideError()
    this.hideLocationRequest()
    this.hideMap()
  }

  hideLoading() {
    document.getElementById("mapLoading").classList.add("hidden")
  }

  showError(title, message) {
    document.getElementById("errorTitle").textContent = title
    document.getElementById("errorMessage").textContent = message
    document.getElementById("mapError").classList.remove("hidden")
    this.hideLoading()
    this.hideLocationRequest()
    this.hideMap()
  }

  hideError() {
    document.getElementById("mapError").classList.add("hidden")
  }

  showLocationRequest(showManualOption = true) {
    document.getElementById("locationRequest").classList.remove("hidden")
    document.getElementById("useManualLocationBtn").style.display = showManualOption ? "block" : "none"
    this.hideLoading()
    this.hideError()
    this.hideMap()
  }

  hideLocationRequest() {
    document.getElementById("locationRequest").classList.add("hidden")
  }

  showMap() {
    document.getElementById("map").classList.remove("hidden")
    document.getElementById("mapControls").classList.remove("hidden")
  }

  hideMap() {
    document.getElementById("map").classList.add("hidden")
    document.getElementById("mapControls").classList.add("hidden")
  }

  // Utility function
  debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
    }
  }

  // Cleanup
  destroy() {
    this.stopLocationTracking()
    this.clearTemporaryMarkers()

    if (this.map) {
      this.map = null
    }

    if (this.marker) {
      this.marker.setMap(null)
      this.marker = null
    }

    if (this.accuracyCircle) {
      this.accuracyCircle.setMap(null)
      this.accuracyCircle = null
    }
  }
}

// Export for use in main app
window.GoogleMapsManager = GoogleMapsManager
