// Geolocation Manager
class GeolocationManager {
  constructor() {
    this.currentPosition = null
    this.watchId = null
    this.isWatching = false

    this.init()
  }

  init() {
    this.checkGeolocationSupport()
    this.startWatching()
  }

  checkGeolocationSupport() {
    if (!("geolocation" in navigator)) {
      throw new Error("Geolocalização não é suportada neste navegador")
    }
  }

  startWatching() {
    if (this.isWatching) return

    const options = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 60000,
    }

    this.watchId = navigator.geolocation.watchPosition(
      (position) => this.onPositionSuccess(position),
      (error) => this.onPositionError(error),
      options,
    )

    this.isWatching = true
  }

  stopWatching() {
    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId)
      this.watchId = null
      this.isWatching = false
    }
  }

  onPositionSuccess(position) {
    this.currentPosition = {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: position.coords.accuracy,
      timestamp: new Date(position.timestamp),
    }

    // Update app location
    if (window.ajudaAiApp) {
      window.ajudaAiApp.updateLocationStatus(position)
    }

    // Store location for offline use
    this.storeLocation()
  }

  onPositionError(error) {
    console.error("Geolocation error:", error)

    let message = "Erro desconhecido"
    switch (error.code) {
      case error.PERMISSION_DENIED:
        message = "Permissão de localização negada"
        break
      case error.POSITION_UNAVAILABLE:
        message = "Localização indisponível"
        break
      case error.TIMEOUT:
        message = "Timeout na obtenção da localização"
        break
    }

    if (window.ajudaAiApp) {
      window.ajudaAiApp.handleLocationError({ message })
    }
  }

  getCurrentPosition() {
    return new Promise((resolve, reject) => {
      if (this.currentPosition) {
        resolve(this.currentPosition)
        return
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          this.onPositionSuccess(position)
          resolve(this.currentPosition)
        },
        (error) => {
          this.onPositionError(error)
          reject(error)
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000,
        },
      )
    })
  }

  storeLocation() {
    if (this.currentPosition) {
      localStorage.setItem("ajudaai_last_location", JSON.stringify(this.currentPosition))
    }
  }

  getStoredLocation() {
    const stored = localStorage.getItem("ajudaai_last_location")
    return stored ? JSON.parse(stored) : null
  }

  formatCoordinates(lat, lng) {
    return `${lat.toFixed(6)}, ${lng.toFixed(6)}`
  }

  getLocationString() {
    if (!this.currentPosition) return "Localização indisponível"

    return `Lat: ${this.currentPosition.latitude.toFixed(6)}, Lng: ${this.currentPosition.longitude.toFixed(6)}`
  }

  getGoogleMapsUrl() {
    if (!this.currentPosition) return null

    return `https://www.google.com/maps?q=${this.currentPosition.latitude},${this.currentPosition.longitude}`
  }
}
