// OpenStreetMap Manager usando Leaflet
class OpenStreetMapManager {
  constructor(app) {
    this.app = app
    this.map = null
    this.userMarker = null
    this.accuracyCircle = null
    this.isTracking = false
    this.watchId = null
    this.currentMapStyle = "standard"

    // Estilos de mapa disponíveis
    this.mapStyles = {
      standard: {
        name: "Padrão",
        url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        attribution: "© OpenStreetMap contributors",
      },
      satellite: {
        name: "Satélite",
        url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        attribution: "© Esri, Maxar, Earthstar Geographics",
      },
      terrain: {
        name: "Terreno",
        url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
        attribution: "© OpenTopoMap contributors",
      },
      dark: {
        name: "Escuro",
        url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
        attribution: "© CartoDB, © OpenStreetMap contributors",
      },
    }

    this.init()
  }

  init() {
    this.setupEventListeners()
    this.initializeMap()
  }

  setupEventListeners() {
    // Retry button
    document.getElementById("retryMapBtn")?.addEventListener("click", () => {
      this.retryMapLoad()
    })

    // Location request buttons
    document.getElementById("requestLocationBtn")?.addEventListener("click", () => {
      this.requestLocation()
    })

    document.getElementById("useManualLocationBtn")?.addEventListener("click", () => {
      this.showManualLocationSelection()
    })

    // Map control buttons
    document.getElementById("centerLocationBtn")?.addEventListener("click", () => {
      this.centerOnUserLocation()
    })

    document.getElementById("shareLocationBtn")?.addEventListener("click", () => {
      this.shareLocation()
    })

    document.getElementById("fullscreenMapBtn")?.addEventListener("click", () => {
      this.toggleFullscreen()
    })

    document.getElementById("changeMapStyle")?.addEventListener("click", () => {
      this.changeMapStyle()
    })

    // Window resize handler
    window.addEventListener(
      "resize",
      this.debounce(() => {
        this.handleResize()
      }, 250),
    )
  }

  async initializeMap() {
    try {
      this.showLoading()

      // Aguarda um pouco para garantir que o Leaflet carregou
      await this.waitForLeaflet()

      // Cria o mapa
      await this.createMap()

      // Solicita localização do usuário
      await this.requestLocation()

      this.hideLoading()
      this.showMap()

      console.log("OpenStreetMap inicializado com sucesso")
    } catch (error) {
      console.error("Falha ao inicializar OpenStreetMap:", error)
      this.showError("Falha ao inicializar o mapa", error.message)
    }
  }

  waitForLeaflet(timeout = 5000) {
    return new Promise((resolve, reject) => {
      const startTime = Date.now()

      const checkLeaflet = () => {
        if (window.L) {
          resolve()
        } else if (Date.now() - startTime > timeout) {
          reject(new Error("Timeout ao carregar Leaflet"))
        } else {
          setTimeout(checkLeaflet, 100)
        }
      }

      checkLeaflet()
    })
  }

  async createMap() {
    const mapElement = document.getElementById("map")
    if (!mapElement) {
      throw new Error("Container do mapa não encontrado")
    }

    // Centro padrão (Petrópolis, RJ)
    const defaultCenter = [-22.5057, -43.1791]

    // Cria o mapa
    this.map = window.L.map(mapElement, {
      center: defaultCenter,
      zoom: 13,
      zoomControl: true,
      attributionControl: true,
    })

    // Adiciona camada de tiles
    this.addTileLayer()

    // Adiciona event listeners
    this.map.on("click", (e) => {
      this.handleMapClick(e.latlng)
    })

    this.map.on("moveend", () => {
      this.onMapMoveEnd()
    })

    console.log("Mapa OpenStreetMap criado")
  }

  addTileLayer() {
    const style = this.mapStyles[this.currentMapStyle]

    if (this.tileLayer) {
      this.map.removeLayer(this.tileLayer)
    }

    this.tileLayer = window.L.tileLayer(style.url, {
      attribution: style.attribution,
      maxZoom: 19,
      tileSize: 256,
      zoomOffset: 0,
    })

    this.tileLayer.addTo(this.map)
  }

  async requestLocation() {
    if (!navigator.geolocation) {
      this.showError("Geolocalização não suportada", "Seu navegador não suporta geolocalização")
      return
    }

    try {
      this.showLocationRequest(false)

      const position = await this.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      })

      await this.updateUserLocation(position)
      this.startLocationTracking()
    } catch (error) {
      console.error("Falha na solicitação de localização:", error)
      this.handleLocationError(error)
    }
  }

  getCurrentPosition(options) {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, options)
    })
  }

  async updateUserLocation(position) {
    const location = {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: position.coords.accuracy,
      timestamp: new Date(position.timestamp),
    }

    // Atualiza localização no app
    this.app.currentLocation = location

    // Atualiza mapa
    await this.updateMapLocation(location)

    // Atualiza UI
    this.updateLocationDisplay(location)

    // Atualiza status
    this.app.updateLocationStatus(position)
  }

  async updateMapLocation(location) {
    if (!this.map) return

    const latLng = [location.latitude, location.longitude]

    // Atualiza centro do mapa
    this.map.setView(latLng, 16)

    // Atualiza ou cria marcador
    if (this.userMarker) {
      this.userMarker.setLatLng(latLng)
    } else {
      this.createUserMarker(latLng)
    }

    // Atualiza círculo de precisão
    this.updateAccuracyCircle(latLng, location.accuracy)

    // Geocodificação reversa para obter endereço
    try {
      const address = await this.reverseGeocode(latLng)
      this.updateMarkerPopup(location, address)
    } catch (error) {
      console.warn("Geocodificação reversa falhou:", error)
      this.updateMarkerPopup(location)
    }
  }

  createUserMarker(latLng) {
    // Ícone personalizado para o usuário
    const userIcon = window.L.divIcon({
      className: "user-location-marker",
      html: `
        <div class="marker-pin">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
            <circle cx="12" cy="10" r="3" fill="#dc2626"/>
          </svg>
        </div>
      `,
      iconSize: [24, 24],
      iconAnchor: [12, 24],
      popupAnchor: [0, -24],
    })

    this.userMarker = window.L.marker(latLng, {
      icon: userIcon,
      title: "Sua Localização Atual",
    }).addTo(this.map)
  }

  updateAccuracyCircle(latLng, accuracy) {
    if (this.accuracyCircle) {
      this.map.removeLayer(this.accuracyCircle)
    }

    this.accuracyCircle = window.L.circle(latLng, {
      color: "#2563eb",
      fillColor: "#2563eb",
      fillOpacity: 0.15,
      radius: accuracy,
      weight: 2,
    }).addTo(this.map)
  }

  async reverseGeocode(latLng) {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latLng[0]}&lon=${latLng[1]}&zoom=18&addressdetails=1`,
      )

      if (!response.ok) {
        throw new Error("Falha na geocodificação")
      }

      const data = await response.json()
      return data.display_name || "Endereço não encontrado"
    } catch (error) {
      throw new Error("Serviço de geocodificação indisponível")
    }
  }

  updateMarkerPopup(location, address = "") {
    if (!this.userMarker) return

    const content = `
      <div class="location-popup">
        <h4>🚨 Sua Localização Atual</h4>
        ${address ? `<p><strong>Endereço:</strong> ${address}</p>` : ""}
        <p><strong>Coordenadas:</strong> ${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}</p>
        <p><strong>Precisão:</strong> ±${Math.round(location.accuracy)}m</p>
        <p><strong>Atualizado:</strong> ${location.timestamp.toLocaleTimeString()}</p>
        <div class="popup-actions">
          <button onclick="window.ajudaAiApp.openStreetMap.shareLocation()" class="popup-btn">
            Compartilhar
          </button>
          <button onclick="window.ajudaAiApp.openStreetMap.centerOnUserLocation()" class="popup-btn">
            Centralizar
          </button>
        </div>
      </div>
    `

    this.userMarker.bindPopup(content)
  }

  handleMapClick(latLng) {
    const lat = latLng.lat
    const lng = latLng.lng

    // Cria marcador temporário
    const tempIcon = window.L.divIcon({
      className: "temp-location-marker",
      html: `
        <div class="marker-pin temp">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
            <circle cx="12" cy="10" r="3" fill="#f59e0b"/>
          </svg>
        </div>
      `,
      iconSize: [20, 20],
      iconAnchor: [10, 20],
      popupAnchor: [0, -20],
    })

    const tempMarker = window.L.marker([lat, lng], { icon: tempIcon }).addTo(this.map)

    // Geocodificação reversa
    this.reverseGeocode([lat, lng])
      .then((address) => {
        const popup = window.L.popup({
          closeButton: true,
          autoClose: false,
          closeOnEscapeKey: true,
        }).setContent(`
          <div class="location-popup">
            <h4>📍 Localização Selecionada</h4>
            <p><strong>Endereço:</strong> ${address}</p>
            <p><strong>Coordenadas:</strong> ${lat.toFixed(6)}, ${lng.toFixed(6)}</p>
            <div class="popup-actions">
              <button onclick="window.ajudaAiApp.openStreetMap.useSelectedLocation(${lat}, ${lng}); window.ajudaAiApp.openStreetMap.removeTempMarker()" class="popup-btn primary">
                Usar Esta Localização
              </button>
              <button onclick="window.ajudaAiApp.openStreetMap.removeTempMarker()" class="popup-btn">
                Cancelar
              </button>
            </div>
          </div>
        `)

        tempMarker.bindPopup(popup).openPopup()
        this.tempMarker = tempMarker
      })
      .catch(() => {
        this.map.removeLayer(tempMarker)
      })
  }

  useSelectedLocation(lat, lng) {
    this.app.currentLocation = {
      latitude: lat,
      longitude: lng,
      accuracy: 10,
      timestamp: new Date(),
    }

    this.updateMapLocation(this.app.currentLocation)
    this.updateLocationDisplay(this.app.currentLocation)
    this.removeTempMarker()

    this.app.showToast("Localização Atualizada", "Localização selecionada manualmente foi definida como atual")
  }

  removeTempMarker() {
    if (this.tempMarker) {
      this.map.removeLayer(this.tempMarker)
      this.tempMarker = null
    }
  }

  startLocationTracking() {
    if (this.isTracking) return

    this.watchId = navigator.geolocation.watchPosition(
      (position) => {
        this.updateUserLocation(position)
      },
      (error) => {
        console.warn("Erro no rastreamento de localização:", error)
      },
      {
        enableHighAccuracy: true,
        timeout: 30000,
        maximumAge: 10000,
      },
    )

    this.isTracking = true
  }

  stopLocationTracking() {
    if (this.watchId) {
      navigator.geolocation.clearWatch(this.watchId)
      this.watchId = null
      this.isTracking = false
    }
  }

  centerOnUserLocation() {
    if (!this.app.currentLocation || !this.map) {
      this.app.showToast("Erro", "Localização não disponível", "error")
      return
    }

    const latLng = [this.app.currentLocation.latitude, this.app.currentLocation.longitude]
    this.map.setView(latLng, 16)

    // Anima o marcador
    if (this.userMarker) {
      this.userMarker.openPopup()
    }
  }

  shareLocation() {
    if (!this.app.currentLocation) {
      this.app.showToast("Erro", "Localização não disponível", "error")
      return
    }

    const { latitude, longitude } = this.app.currentLocation
    const url = `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}&zoom=16`

    if (navigator.share) {
      navigator
        .share({
          title: "Minha Localização - AjudaAí",
          text: `Estou aqui: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
          url: url,
        })
        .catch(console.error)
    } else {
      // Fallback para clipboard
      navigator.clipboard
        .writeText(url)
        .then(() => {
          this.app.showToast("Link Copiado", "Link da localização copiado para a área de transferência")
        })
        .catch(() => {
          // Fallback para prompt
          prompt("Copie o link da sua localização:", url)
        })
    }
  }

  changeMapStyle() {
    const styles = Object.keys(this.mapStyles)
    const currentIndex = styles.indexOf(this.currentMapStyle)
    const nextIndex = (currentIndex + 1) % styles.length

    this.currentMapStyle = styles[nextIndex]
    this.addTileLayer()

    const styleName = this.mapStyles[this.currentMapStyle].name
    this.app.showToast("Estilo Alterado", `Mapa alterado para: ${styleName}`)
  }

  toggleFullscreen() {
    const mapContainer = document.getElementById("mapContainer")

    if (!document.fullscreenElement) {
      mapContainer
        .requestFullscreen()
        .then(() => {
          mapContainer.classList.add("fullscreen")
          this.handleResize()
        })
        .catch(console.error)
    } else {
      document
        .exitFullscreen()
        .then(() => {
          mapContainer.classList.remove("fullscreen")
          this.handleResize()
        })
        .catch(console.error)
    }
  }

  handleResize() {
    if (this.map) {
      setTimeout(() => {
        this.map.invalidateSize()
        if (this.app.currentLocation) {
          this.centerOnUserLocation()
        }
      }, 100)
    }
  }

  onMapMoveEnd() {
    // Mapa terminou de se mover
    this.hideLoading()
  }

  handleLocationError(error) {
    let title = "Erro de Localização"
    let message = "Não foi possível obter sua localização"

    switch (error.code) {
      case error.PERMISSION_DENIED:
        title = "Permissão Negada"
        message =
          'Você negou o acesso à localização. Clique em "Selecionar Manualmente" para escolher sua localização no mapa.'
        break
      case error.POSITION_UNAVAILABLE:
        title = "Localização Indisponível"
        message = "Informações de localização não estão disponíveis no momento."
        break
      case error.TIMEOUT:
        title = "Tempo Esgotado"
        message = "A solicitação de localização expirou. Tente novamente."
        break
    }

    this.showLocationRequest(true)
    this.app.showToast(title, message, "error")
  }

  retryMapLoad() {
    this.hideError()
    this.initializeMap()
  }

  showManualLocationSelection() {
    this.hideLocationRequest()
    this.showMap()

    if (!this.map) {
      this.createMap()
    }

    this.app.showToast("Seleção Manual", "Clique no mapa para selecionar sua localização")
  }

  updateLocationDisplay(location) {
    document.getElementById("currentLat").textContent = location.latitude.toFixed(6)
    document.getElementById("currentLng").textContent = location.longitude.toFixed(6)
    document.getElementById("currentAccuracy").textContent = `±${Math.round(location.accuracy)}m`
    document.getElementById("lastUpdate").textContent = location.timestamp.toLocaleTimeString()

    document.getElementById("locationInfoPanel").classList.remove("hidden")
  }

  // UI State Management
  showLoading() {
    document.getElementById("mapLoading").classList.remove("hidden")
    this.hideError()
    this.hideLocationRequest()
    this.hideMap()
  }

  hideLoading() {
    document.getElementById("mapLoading").classList.add("hidden")
  }

  showError(title, message) {
    document.getElementById("errorTitle").textContent = title
    document.getElementById("errorMessage").textContent = message
    document.getElementById("mapError").classList.remove("hidden")
    this.hideLoading()
    this.hideLocationRequest()
    this.hideMap()
  }

  hideError() {
    document.getElementById("mapError").classList.add("hidden")
  }

  showLocationRequest(showManualOption = true) {
    document.getElementById("locationRequest").classList.remove("hidden")
    document.getElementById("useManualLocationBtn").style.display = showManualOption ? "block" : "none"
    this.hideLoading()
    this.hideError()
    this.hideMap()
  }

  hideLocationRequest() {
    document.getElementById("locationRequest").classList.add("hidden")
  }

  showMap() {
    document.getElementById("map").classList.remove("hidden")
    document.getElementById("mapControls").classList.remove("hidden")
  }

  hideMap() {
    document.getElementById("map").classList.add("hidden")
    document.getElementById("mapControls").classList.add("hidden")
  }

  // Utility function
  debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
    }
  }

  // Cleanup
  destroy() {
    this.stopLocationTracking()
    this.removeTempMarker()

    if (this.map) {
      this.map.remove()
      this.map = null
    }

    if (this.userMarker) {
      this.userMarker = null
    }

    if (this.accuracyCircle) {
      this.accuracyCircle = null
    }
  }
}

// Export para uso no app principal
window.OpenStreetMapManager = OpenStreetMapManager
