// Main Application Controller - Atualizado para TomTom Maps
class AjudaAiApp {
  constructor() {
    this.currentTab = "emergency"
    this.currentLocation = null
    this.isEmergencyActive = false
    this.contacts = []
    this.alerts = []
    this.selectedRecipients = []

    // TomTom Maps integration
    this.tomtomMap = null
    this.mapLoaded = false

    this.init()
  }

  init() {
    this.setupEventListeners()
    this.loadStoredData()
    this.initializeGeolocation()
    this.renderContacts()
    this.renderAlerts()

    // Initialize TomTom Maps
    this.initializeTomTomMaps()

    console.log("AjudaAí App inicializado com TomTom Maps")
  }

  initializeTomTomMaps() {
    // Aguarda o TomTomManager estar disponível
    if (typeof window.TomTomManager !== "undefined") {
      this.tomtomMap = new window.TomTomManager(this)
      this.mapLoaded = true
    } else {
      // Tenta novamente após um pequeno delay
      setTimeout(() => {
        this.initializeTomTomMaps()
      }, 100)
    }
  }

  setupEventListeners() {
    // Tab navigation
    document.querySelectorAll(".nav-tab").forEach((tab) => {
      tab.addEventListener("click", (e) => {
        const tabName = e.currentTarget.dataset.tab
        this.switchTab(tabName)
      })
    })

    // Emergency buttons
    document.querySelectorAll(".emergency-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const serviceId = e.currentTarget.dataset.service
        this.sendEmergencyAlert(serviceId)
      })
    })

    // Discrete alert
    document.getElementById("discreteAlert").addEventListener("click", () => {
      this.sendDiscreteAlert()
    })

    // Contact management
    document.getElementById("addContactBtn").addEventListener("click", () => {
      this.openAddContactModal()
    })

    document.getElementById("saveContact").addEventListener("click", () => {
      this.saveContact()
    })

    document.getElementById("cancelContact").addEventListener("click", () => {
      this.closeModal("contactModal")
    })

    // Alert management
    document.getElementById("createAlertBtn").addEventListener("click", () => {
      this.openCreateAlertModal()
    })

    document.getElementById("saveAlert").addEventListener("click", () => {
      this.saveAlert()
    })

    document.getElementById("cancelAlert").addEventListener("click", () => {
      this.closeModal("alertModal")
    })

    // Modal close buttons
    document.querySelectorAll(".modal-close").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const modal = e.target.closest(".modal")
        this.closeModal(modal)
      })
    })

    // Click outside modal to close
    document.querySelectorAll(".modal").forEach((modal) => {
      modal.addEventListener("click", (e) => {
        if (e.target === modal) {
          this.closeModal(modal)
        }
      })
    })

    // Settings toggles
    document.getElementById("vibrationSetting").addEventListener("change", (e) => {
      this.saveSetting("vibration", e.target.checked)
    })

    document.getElementById("soundSetting").addEventListener("change", (e) => {
      this.saveSetting("sound", e.target.checked)
    })

    document.getElementById("offlineSetting").addEventListener("change", (e) => {
      this.saveSetting("offline", e.target.checked)
    })

    // Recipient buttons
    document.querySelectorAll(".recipient-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault()
        this.toggleRecipient(e.currentTarget)
      })
    })
  }

  // Tab Management
  switchTab(tabName) {
    document.querySelectorAll(".nav-tab").forEach((tab) => {
      tab.classList.remove("active")
    })
    document.querySelector(`[data-tab="${tabName}"]`).classList.add("active")

    document.querySelectorAll(".tab-content").forEach((content) => {
      content.classList.remove("active")
    })
    document.getElementById(`${tabName}-tab`).classList.add("active")

    this.currentTab = tabName
  }

  // Modal Management
  showModal(modalId) {
    const modal = document.getElementById(modalId)
    modal.classList.add("show")
    document.body.style.overflow = "hidden"
  }

  closeModal(modal) {
    if (typeof modal === "string") {
      modal = document.getElementById(modal)
    }
    modal.classList.remove("show")
    document.body.style.overflow = ""
  }

  // Toast Notifications
  showToast(title, message, type = "success") {
    const toast = document.createElement("div")
    toast.className = `toast ${type}`
    toast.innerHTML = `
      <div class="toast-title">${title}</div>
      <div class="toast-message">${message}</div>
    `

    const container = document.getElementById("toastContainer")
    container.appendChild(toast)

    setTimeout(() => {
      toast.remove()
    }, 5000)

    toast.addEventListener("click", () => {
      toast.remove()
    })
  }

  // Emergency Functions
  async sendEmergencyAlert(serviceId) {
    if (this.isEmergencyActive) return

    const services = {
      samu: { name: "SAMU", phone: "192" },
      bombeiros: { name: "Bombeiros", phone: "193" },
      "defesa-civil": { name: "Defesa Civil", phone: "199" },
      policia: { name: "Polícia", phone: "190" },
    }

    const service = services[serviceId]
    if (!service) return

    const location = await this.getCurrentLocation()
    if (!location) {
      this.showToast("Erro", "Localização não disponível. Tentando obter localização...", "error")
      return
    }

    this.isEmergencyActive = true
    this.showEmergencyOverlay()

    try {
      await this.processEmergencyAlert(service, location)

      this.vibrate([200, 100, 200, 100, 200])
      this.playSound("success")

      this.showToast("Alerta Enviado!", `${service.name} foi notificado da sua localização. Aguarde o atendimento.`)

      this.logEmergency(service, location)
    } catch (error) {
      console.error("Emergency alert error:", error)
      this.showToast("Erro", "Falha ao enviar alerta. Tente novamente.", "error")
    } finally {
      setTimeout(() => {
        this.hideEmergencyOverlay()
        this.isEmergencyActive = false
      }, 3000)
    }
  }

  async sendDiscreteAlert() {
    const location = await this.getCurrentLocation()
    if (!location) {
      this.showToast("Erro", "Localização não disponível", "error")
      return
    }

    const message = `Preciso de ajuda urgente. Localização: https://www.google.com/maps?q=${location.latitude},${location.longitude}`
    const notifiedCount = this.notifyContacts(message, location, "high")

    if (notifiedCount > 0) {
      this.vibrate([100])
      this.showToast("Alerta Discreto Enviado", "Seus contatos de emergência foram notificados discretamente.")
      this.logDiscreteAlert(location, notifiedCount)
    } else {
      this.showToast("Erro", "Nenhum contato de alta prioridade encontrado", "error")
    }
  }

  async processEmergencyAlert(service, location) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log(`Emergency alert sent to ${service.name}:`, {
          service: service.name,
          phone: service.phone,
          location: {
            latitude: location.latitude,
            longitude: location.longitude,
            accuracy: location.accuracy,
          },
          timestamp: new Date(),
          address: `Lat: ${location.latitude.toFixed(6)}, Lng: ${location.longitude.toFixed(6)}`,
          tomtomUrl: `https://www.google.com/maps?q=${location.latitude},${location.longitude}`,
        })
        resolve()
      }, 2000)
    })
  }

  showEmergencyOverlay() {
    const overlay = document.getElementById("emergencyOverlay")
    overlay.classList.remove("hidden")
    document.body.style.overflow = "hidden"
  }

  hideEmergencyOverlay() {
    const overlay = document.getElementById("emergencyOverlay")
    overlay.classList.add("hidden")
    document.body.style.overflow = ""
  }

  // Geolocation
  initializeGeolocation() {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          this.updateLocationStatus(position)
        },
        (error) => {
          this.handleLocationError(error)
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000,
        },
      )
    } else {
      this.handleLocationError({ message: "Geolocalização não suportada" })
    }
  }

  updateLocationStatus(position) {
    this.currentLocation = {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: position.coords.accuracy,
      timestamp: new Date(),
    }

    document.getElementById("locationStatus").classList.remove("hidden")
    document.getElementById("errorStatus").classList.add("hidden")

    // Update TomTom Map if available
    if (this.tomtomMap) {
      this.tomtomMap.updateUserLocation(position)
    }
  }

  handleLocationError(error) {
    console.error("Location error:", error)

    document.getElementById("locationStatus").classList.add("hidden")
    document.getElementById("errorStatus").classList.remove("hidden")

    // Handle error in TomTom Map
    if (this.tomtomMap) {
      this.tomtomMap.handleLocationError(error)
    }

    this.showToast("Erro de Localização", "Não foi possível obter sua localização. Verifique as permissões.", "error")
  }

  async getCurrentLocation() {
    try {
      if (this.currentLocation) {
        return this.currentLocation
      }

      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 30000,
        })
      })

      return {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: new Date(),
      }
    } catch (error) {
      console.error("Location error:", error)
      return null
    }
  }

  // Contact Management
  loadStoredData() {
    const settings = JSON.parse(localStorage.getItem("ajudaai_settings") || "{}")
    const contacts = JSON.parse(localStorage.getItem("ajudaai_contacts") || "[]")
    const alerts = JSON.parse(localStorage.getItem("ajudaai_alerts") || "[]")

    document.getElementById("vibrationSetting").checked = settings.vibration !== false
    document.getElementById("soundSetting").checked = settings.sound !== false
    document.getElementById("offlineSetting").checked = settings.offline !== false

    this.contacts = contacts.length > 0 ? contacts : this.getDefaultContacts()
    this.alerts = alerts.length > 0 ? alerts : this.getDefaultAlerts()
  }

  getDefaultContacts() {
    return [
      {
        id: "1",
        name: "Maria Silva",
        phone: "(24) 99999-1234",
        email: "maria@email.com",
        relationship: "Família",
        priority: "high",
      },
      {
        id: "2",
        name: "João Santos",
        phone: "(24) 98888-5678",
        email: "joao@email.com",
        relationship: "Amigo",
        priority: "medium",
      },
    ]
  }

  getDefaultAlerts() {
    return [
      {
        id: "1",
        name: "Assalto Discreto",
        message: "Preciso de ajuda urgente. Localização anexa.",
        isDiscrete: true,
        autoLocation: true,
        delay: 0,
        recipients: ["Família", "Amigos"],
        trigger: "manual",
      },
      {
        id: "2",
        name: "Acidente de Trânsito",
        message: "Sofri um acidente de trânsito. Preciso de ajuda.",
        isDiscrete: false,
        autoLocation: true,
        delay: 30,
        recipients: ["Família"],
        trigger: "manual",
      },
    ]
  }

  openAddContactModal() {
    document.getElementById("contactForm").reset()
    this.showModal("contactModal")
  }

  saveContact() {
    const name = document.getElementById("contactName").value.trim()
    const phone = document.getElementById("contactPhone").value.trim()
    const email = document.getElementById("contactEmail").value.trim()
    const relationship = document.getElementById("contactRelationship").value
    const priority = document.getElementById("contactPriority").value

    if (!name || !phone) {
      this.showToast("Erro", "Nome e telefone são obrigatórios", "error")
      return
    }

    const contact = {
      id: Date.now().toString(),
      name,
      phone: this.formatPhone(phone),
      email,
      relationship,
      priority,
    }

    this.contacts.push(contact)
    this.saveContacts()
    this.renderContacts()

    this.closeModal("contactModal")
    this.showToast("Contato Adicionado", `${contact.name} foi adicionado aos seus contatos de emergência`)
  }

  removeContact(id) {
    this.contacts = this.contacts.filter((c) => c.id !== id)
    this.saveContacts()
    this.renderContacts()
    this.showToast("Contato Removido", "Contato removido da lista de emergência")
  }

  saveContacts() {
    localStorage.setItem("ajudaai_contacts", JSON.stringify(this.contacts))
  }

  renderContacts() {
    const container = document.getElementById("contactsList")

    if (this.contacts.length === 0) {
      container.innerHTML = this.getContactsEmptyState()
      return
    }

    container.innerHTML = this.contacts.map((contact) => this.renderContact(contact)).join("")
    this.setupContactActions()
  }

  renderContact(contact) {
    return `
      <div class="contact-item" data-id="${contact.id}">
        <div class="contact-info">
          <div class="contact-header">
            <span class="contact-name">${contact.name}</span>
            <span class="badge priority-${contact.priority}">${this.getPriorityLabel(contact.priority)}</span>
            <span class="badge relationship">${contact.relationship}</span>
          </div>
          <div class="contact-details">
            <div class="contact-detail">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
              </svg>
              ${contact.phone}
            </div>
            ${
              contact.email
                ? `
              <div class="contact-detail">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                  <polyline points="22,6 12,13 2,6"/>
                </svg>
                ${contact.email}
              </div>
            `
                : ""
            }
          </div>
        </div>
        <div class="contact-actions">
          <button class="btn btn-secondary remove-contact" data-id="${contact.id}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3,6 5,6 21,6"/>
              <path d="m19,6v14a2,2 0 0,0-4,2H7a2,2 0 0,0-4,-2V6m3,0V4a2,2 0 0,0 2,-2h4a2,2 0 0,0 2,2v2"/>
            </svg>
          </button>
        </div>
      </div>
    `
  }

  setupContactActions() {
    document.querySelectorAll(".remove-contact").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.currentTarget.dataset.id
        if (confirm("Tem certeza que deseja remover este contato?")) {
          this.removeContact(id)
        }
      })
    })
  }

  getContactsEmptyState() {
    return `
      <div class="empty-state">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
          <circle cx="9" cy="7" r="4"/>
          <path d="m22 21-3-3m0 0a5.5 5.5 0 1 0-7.78-7.78 5.5 5.5 0 0 0 7.78 7.78Z"/>
        </svg>
        <h3>Nenhum contato de emergência cadastrado</h3>
        <p>Adicione pessoas que devem ser notificadas em caso de emergência</p>
      </div>
    `
  }

  // Alert Management
  openCreateAlertModal() {
    document.getElementById("alertForm").reset()
    this.selectedRecipients = []
    this.updateRecipientButtons()
    this.showModal("alertModal")
  }

  saveAlert() {
    const name = document.getElementById("alertName").value.trim()
    const message = document.getElementById("alertMessage").value.trim()
    const isDiscrete = document.getElementById("alertDiscrete").checked
    const autoLocation = document.getElementById("alertLocation").checked
    const delay = Number.parseInt(document.getElementById("alertDelay").value)

    if (!name || !message) {
      this.showToast("Erro", "Nome e mensagem são obrigatórios", "error")
      return
    }

    if (this.selectedRecipients.length === 0) {
      this.showToast("Erro", "Selecione pelo menos um grupo de destinatários", "error")
      return
    }

    const alert = {
      id: Date.now().toString(),
      name,
      message,
      isDiscrete,
      autoLocation,
      delay,
      recipients: [...this.selectedRecipients],
      trigger: "manual",
      createdAt: new Date(),
    }

    this.alerts.push(alert)
    this.saveAlerts()
    this.renderAlerts()

    this.closeModal("alertModal")
    this.showToast("Alerta Criado", `Alerta "${alert.name}" foi criado com sucesso`)
  }

  removeAlert(id) {
    this.alerts = this.alerts.filter((a) => a.id !== id)
    this.saveAlerts()
    this.renderAlerts()
    this.showToast("Alerta Removido", "Alerta personalizado foi removido")
  }

  saveAlerts() {
    localStorage.setItem("ajudaai_alerts", JSON.stringify(this.alerts))
  }

  toggleRecipient(button) {
    const recipient = button.dataset.recipient

    if (this.selectedRecipients.includes(recipient)) {
      this.selectedRecipients = this.selectedRecipients.filter((r) => r !== recipient)
      button.classList.remove("active")
    } else {
      this.selectedRecipients.push(recipient)
      button.classList.add("active")
    }
  }

  updateRecipientButtons() {
    document.querySelectorAll(".recipient-btn").forEach((btn) => {
      const recipient = btn.dataset.recipient
      if (this.selectedRecipients.includes(recipient)) {
        btn.classList.add("active")
      } else {
        btn.classList.remove("active")
      }
    })
  }

  renderAlerts() {
    const container = document.getElementById("alertsList")

    if (this.alerts.length === 0) {
      container.innerHTML = this.getAlertsEmptyState()
      return
    }

    container.innerHTML = this.alerts.map((alert) => this.renderAlert(alert)).join("")
    this.setupAlertActions()
  }

  renderAlert(alert) {
    return `
      <div class="alert-item" data-id="${alert.id}">
        <div class="alert-content">
          <div class="alert-info">
            <div class="alert-header">
              <span class="alert-name">${alert.name}</span>
              ${alert.isDiscrete ? '<span class="badge">Discreto</span>' : ""}
              ${alert.autoLocation ? '<span class="badge relationship">Com GPS</span>' : ""}
              ${alert.delay > 0 ? `<span class="badge relationship">${alert.delay}s</span>` : ""}
            </div>
            <p class="alert-message">${alert.message}</p>
            <div class="alert-recipients">
              <span>Destinatários:</span>
              ${alert.recipients.map((recipient) => `<span class="badge relationship">${recipient}</span>`).join("")}
            </div>
          </div>
          <div class="alert-actions">
            <button class="btn alert-trigger trigger-alert" data-id="${alert.id}">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/>
                <path d="M12 9v4"/>
                <path d="m12 17 .01 0"/>
              </svg>
              Ativar
            </button>
            <button class="btn btn-secondary remove-alert" data-id="${alert.id}">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3,6 5,6 21,6"/>
                <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    `
  }

  setupAlertActions() {
    document.querySelectorAll(".trigger-alert").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.currentTarget.dataset.id
        this.triggerAlert(id)
      })
    })

    document.querySelectorAll(".remove-alert").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const id = e.currentTarget.dataset.id
        if (confirm("Tem certeza que deseja remover este alerta?")) {
          this.removeAlert(id)
        }
      })
    })
  }

  triggerAlert(id) {
    const alert = this.alerts.find((a) => a.id === id)
    if (!alert) return

    const executeAlert = async () => {
      let location = null
      if (alert.autoLocation) {
        location = await this.getCurrentLocation()
      }

      this.executeAlert(alert, location)
    }

    if (alert.delay > 0) {
      this.showToast("Alerta Agendado", `"${alert.name}" será enviado em ${alert.delay} segundos`, "warning")
      setTimeout(executeAlert, alert.delay * 1000)
    } else {
      executeAlert()
    }
  }

  executeAlert(alert, location) {
    let message = alert.message
    if (location) {
      message += `\n\nLocalização: https://www.google.com/maps?q=${location.latitude},${location.longitude}`
    }

    let totalNotified = 0
    alert.recipients.forEach((recipientGroup) => {
      const contacts = this.getContactsByRelationship(recipientGroup)
      contacts.forEach((contact) => {
        this.sendNotification(contact, message, location)
        totalNotified++
      })
    })

    this.vibrate([200, 100, 200])
    this.playSound("success")

    this.showToast("Alerta Ativado", `"${alert.name}" foi enviado para ${totalNotified} contatos`)
    this.logAlertActivation(alert, location, totalNotified)
  }

  getAlertsEmptyState() {
    return `
      <div class="empty-state">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
        <h3>Nenhum alerta personalizado criado</h3>
        <p>Crie alertas específicos para diferentes situações</p>
      </div>
    `
  }

  // Utility Functions
  formatPhone(phone) {
    const cleaned = phone.replace(/\D/g, "")
    if (cleaned.length === 11) {
      return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7)}`
    }
    return phone
  }

  getPriorityLabel(priority) {
    const labels = {
      high: "Alta",
      medium: "Média",
      low: "Baixa",
    }
    return labels[priority] || "Média"
  }

  getContactsByRelationship(relationship) {
    return this.contacts.filter((contact) => contact.relationship === relationship)
  }

  notifyContacts(message, location = null, priority = "all") {
    let contactsToNotify = this.contacts

    if (priority !== "all") {
      contactsToNotify = this.contacts.filter((contact) => contact.priority === priority)
    }

    contactsToNotify.forEach((contact) => {
      this.sendNotification(contact, message, location)
    })

    return contactsToNotify.length
  }

  sendNotification(contact, message, location) {
    console.log(`Sending notification to ${contact.name} (${contact.phone}):`, {
      message,
      location,
      timestamp: new Date(),
    })

    setTimeout(() => {
      console.log(`Notification sent to ${contact.name}`)
    }, 1000)
  }

  saveSetting(key, value) {
    const settings = JSON.parse(localStorage.getItem("ajudaai_settings") || "{}")
    settings[key] = value
    localStorage.setItem("ajudaai_settings", JSON.stringify(settings))
  }

  getSetting(key, defaultValue = true) {
    const settings = JSON.parse(localStorage.getItem("ajudaai_settings") || "{}")
    return settings[key] !== undefined ? settings[key] : defaultValue
  }

  vibrate(pattern = [200, 100, 200]) {
    if (this.getSetting("vibration") && "vibrate" in navigator) {
      navigator.vibrate(pattern)
    }
  }

  playSound(type = "success") {
    if (!this.getSetting("sound")) return

    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      const frequency = type === "success" ? 800 : type === "error" ? 400 : 600
      oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime)
      oscillator.type = "sine"

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5)

      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.5)
    } catch (error) {
      console.log("Audio not supported")
    }
  }

  logEmergency(service, location) {
    const log = {
      type: "emergency",
      service: service.name,
      servicePhone: service.phone,
      location: {
        latitude: location.latitude,
        longitude: location.longitude,
        accuracy: location.accuracy,
      },
      timestamp: new Date(),
      status: "sent",
    }

    this.saveEmergencyLog(log)
  }

  logDiscreteAlert(location, contactsNotified) {
    const log = {
      type: "discrete",
      location: {
        latitude: location.latitude,
        longitude: location.longitude,
        accuracy: location.accuracy,
      },
      contactsNotified,
      timestamp: new Date(),
      status: "sent",
    }

    this.saveEmergencyLog(log)
  }

  logAlertActivation(alert, location, contactsNotified) {
    const log = {
      alertId: alert.id,
      alertName: alert.name,
      timestamp: new Date(),
      location: location
        ? {
            latitude: location.latitude,
            longitude: location.longitude,
          }
        : null,
      contactsNotified,
      recipients: alert.recipients,
    }

    const history = JSON.parse(localStorage.getItem("ajudaai_alert_history") || "[]")
    history.unshift(log)

    if (history.length > 50) {
      history.splice(50)
    }

    localStorage.setItem("ajudaai_alert_history", JSON.stringify(history))
  }

  saveEmergencyLog(log) {
    const logs = JSON.parse(localStorage.getItem("ajudaai_emergency_logs") || "[]")
    logs.unshift(log)

    if (logs.length > 100) {
      logs.splice(100)
    }

    localStorage.setItem("ajudaai_emergency_logs", JSON.stringify(logs))
  }
}

// Initialize app when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  window.ajudaAiApp = new AjudaAiApp()
})
