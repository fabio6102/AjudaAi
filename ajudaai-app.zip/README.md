# AjudaAí - Aplicativo de Emergência

Aplicativo de segurança e auxílio rápido desenvolvido para a cidade de Petrópolis, permitindo envio de alertas geolocalizados para serviços de emergência e contatos pessoais.

## 🚨 Funcionalidades

### Emergência Rápida
- Botões diretos para SAMU (192), Bombeiros (193), Defesa Civil (199) e Polícia (190)
- Envio de alertas com localização GPS em tempo real
- Interface otimizada para situações de estresse

### Contatos de Emergência
- Cadastro de contatos pessoais com prioridades
- Notificação automática baseada na urgência
- Classificação por relacionamento (Família, Amigos, etc.)

### Alertas Personalizados
- Criação de alertas específicos para diferentes situações
- Modo discreto para situações como assaltos
- Configuração de atraso e destinatários

### Geolocalização
- GPS em tempo real com alta precisão
- Compartilhamento automático da localização
- Funciona offline com última localização conhecida

## 🛠️ Tecnologias

- **HTML5** - Estrutura semântica
- **CSS3** - Design responsivo e moderno
- **JavaScript ES6+** - Funcionalidades interativas
- **Geolocation API** - Localização GPS
- **LocalStorage** - Armazenamento local
- **Service Worker** - Funcionalidade PWA
- **Web Manifest** - Instalação como app

## 📱 Como Usar

### Instalação
1. Abra o arquivo `index.html` no navegador
2. Permita acesso à localização quando solicitado
3. Para usar como PWA, clique em "Adicionar à tela inicial"

### Uso Básico
1. **Emergência**: Toque no botão do serviço desejado
2. **Alerta Discreto**: Use para situações delicadas
3. **Contatos**: Configure pessoas para notificar
4. **Alertas**: Crie mensagens personalizadas

## 🏗️ Estrutura do Projeto

\`\`\`
ajudaai/
├── index.html              # Página principal
├── manifest.json           # Configuração PWA
├── sw.js                  # Service Worker
├── css/
│   ├── styles.css         # Estilos principais
│   └── components.css     # Componentes UI
├── js/
│   ├── app.js            # Controlador principal
│   ├── geolocation.js    # Gerenciador GPS
│   ├── contacts.js       # Gerenciador de contatos
│   ├── alerts.js         # Gerenciador de alertas
│   └── emergency.js      # Gerenciador de emergências
└── assets/
    ├── icon-192.png      # Ícone PWA 192x192
    └── icon-512.png      # Ícone PWA 512x512
\`\`\`

## 🎯 Funcionalidades Técnicas

### Geolocalização
- Monitoramento contínuo da posição
- Fallback para última localização conhecida
- Precisão configurável

### Armazenamento
- Contatos salvos localmente
- Alertas personalizados persistentes
- Histórico de emergências
- Configurações do usuário

### PWA (Progressive Web App)
- Funciona offline
- Instalável como aplicativo
- Cache inteligente
- Notificações push (futuro)

### Responsividade
- Design mobile-first
- Adaptável a diferentes telas
- Touch-friendly para emergências

## 🔧 Configuração

### Permissões Necessárias
- **Localização**: Para GPS em tempo real
- **Notificações**: Para alertas do sistema
- **Vibração**: Para feedback tátil

### Navegadores Suportados
- Chrome 60+
- Firefox 55+
- Safari 11+
- Edge 79+

## 📊 Dados Armazenados

### LocalStorage
- `ajudaai_contacts`: Lista de contatos
- `ajudaai_alerts`: Alertas personalizados
- `ajudaai_settings`: Configurações do usuário
- `ajudaai_emergency_logs`: Histórico de emergências
- `ajudaai_last_location`: Última localização conhecida

## 🚀 Desenvolvimento

### Executar Localmente
1. Clone ou baixe os arquivos
2. Abra `index.html` no navegador
3. Use um servidor local para PWA completa:
   \`\`\`bash
   python -m http.server 8000
   # ou
   npx serve .
   \`\`\`

### Personalização
- Modifique `css/styles.css` para temas
- Ajuste `js/app.js` para configurações
- Edite `manifest.json` para PWA

## 📱 Instalação como PWA

### Android
1. Abra no Chrome
2. Toque no menu (⋮)
3. Selecione "Adicionar à tela inicial"

### iOS
1. Abra no Safari
2. Toque no botão compartilhar
3. Selecione "Adicionar à Tela de Início"

### Desktop
1. Abra no Chrome/Edge
2. Clique no ícone de instalação na barra de endereços
3. Confirme a instalação

## 🔒 Privacidade e Segurança

- Dados armazenados apenas localmente
- Localização não é enviada para servidores externos
- Contatos mantidos privados no dispositivo
- Código aberto para auditoria

## 🤝 Contribuição

Desenvolvido por alunos do SENAI Petrópolis:
- André Mazala Carius
- Arthur Santos Oliveira
- Caio Santos Oliveira
- Fábio de Carvalho Leal
- Frederico Bassoto Villa Campo

## 📄 Licença

Este projeto foi desenvolvido como Trabalho de Conclusão de Curso (TCC) para o SENAI Petrópolis, com foco em segurança pública e auxílio à comunidade.

## 🆘 Suporte

Para emergências reais, sempre ligue diretamente:
- **SAMU**: 192
- **Bombeiros**: 193
- **Polícia**: 190
- **Defesa Civil**: 199

Este aplicativo é uma ferramenta complementar e não substitui os canais oficiais de emergência.
