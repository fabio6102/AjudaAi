// Configuração da API do Google Maps
class GoogleMapsAPIConfig {
  constructor() {
    // SUBSTITUA ESTA CHAVE PELA SUA CHAVE API REAL
    this.apiKey = "SUA_CHAVE_API_AQUI"

    // Configurações da API
    this.libraries = ["geometry", "places"]
    this.version = "weekly"
    this.region = "BR"
    this.language = "pt-BR"
  }

  // Método para configurar a chave API
  setApiKey(apiKey) {
    this.apiKey = apiKey
    this.updateScriptTag()
  }

  // Atualiza o script tag com a nova chave
  updateScriptTag() {
    const existingScript = document.querySelector('script[src*="maps.googleapis.com"]')
    if (existingScript) {
      existingScript.remove()
    }

    const script = document.createElement("script")
    script.src = this.getScriptUrl()
    script.async = true
    script.defer = true
    document.head.appendChild(script)
  }

  // Gera a URL completa da API
  getScriptUrl() {
    const params = new URLSearchParams({
      key: this.apiKey,
      callback: "initMap",
      v: this.version,
      libraries: this.libraries.join(","),
      region: this.region,
      language: this.language,
    })

    return `https://maps.googleapis.com/maps/api/js?${params.toString()}`
  }

  // Valida se a chave API está configurada
  isConfigured() {
    return this.apiKey && this.apiKey !== "SUA_CHAVE_API_AQUI"
  }

  // Testa se a API está funcionando
  async testAPI() {
    if (!this.isConfigured()) {
      throw new Error("Chave API não configurada")
    }

    try {
      // Aguarda o Google Maps carregar
      await this.waitForGoogleMaps()
      console.log("✅ Google Maps API carregada com sucesso!")
      return true
    } catch (error) {
      console.error("❌ Erro ao carregar Google Maps API:", error)
      throw error
    }
  }

  // Aguarda o Google Maps carregar
  waitForGoogleMaps(timeout = 10000) {
    return new Promise((resolve, reject) => {
      const startTime = Date.now()

      const checkGoogleMaps = () => {
        if (window.google && window.google.maps) {
          resolve()
        } else if (Date.now() - startTime > timeout) {
          reject(new Error("Timeout ao carregar Google Maps"))
        } else {
          setTimeout(checkGoogleMaps, 100)
        }
      }

      checkGoogleMaps()
    })
  }
}

// Instância global
window.googleMapsConfig = new GoogleMapsAPIConfig()

// Função para configurar a API facilmente
window.setupGoogleMapsAPI = (apiKey) => {
  window.googleMapsConfig.setApiKey(apiKey)
  console.log("🔑 Chave API configurada:", apiKey.substring(0, 10) + "...")
}
