// Google Maps Configuration and Security
class MapsConfig {
  constructor() {
    this.apiKey = this.getApiKey()
    this.libraries = ["geometry", "places"]
    this.version = "weekly"
    this.region = "BR"
    this.language = "pt-BR"
  }

  getApiKey() {
    // In production, use environment variables or secure configuration
    // For development, you can set it here temporarily
    const apiKey = process.env.GOOGLE_MAPS_API_KEY || window.GOOGLE_MAPS_API_KEY || "YOUR_GOOGLE_MAPS_API_KEY"

    if (apiKey === "YOUR_GOOGLE_MAPS_API_KEY") {
      console.warn("⚠️ Please set your Google Maps API key in the environment variables or configuration")
    }

    return apiKey
  }

  getScriptUrl() {
    const params = new URLSearchParams({
      key: this.apiKey,
      callback: "initMap",
      v: this.version,
      libraries: this.libraries.join(","),
      region: this.region,
      language: this.language,
    })

    return `https://maps.googleapis.com/maps/api/js?${params.toString()}`
  }

  // Security: Restrict API key usage
  validateDomain() {
    const allowedDomains = [
      "localhost",
      "127.0.0.1",
      "your-domain.com", // Add your production domain
    ]

    const currentDomain = window.location.hostname
    return allowedDomains.includes(currentDomain)
  }

  // Performance: Load maps script dynamically
  loadMapsScript() {
    return new Promise((resolve, reject) => {
      if (window.google && window.google.maps) {
        resolve()
        return
      }

      if (!this.validateDomain()) {
        reject(new Error("Domain not authorized for Google Maps API"))
        return
      }

      const script = document.createElement("script")
      script.src = this.getScriptUrl()
      script.async = true
      script.defer = true

      script.onload = () => resolve()
      script.onerror = () => reject(new Error("Failed to load Google Maps API"))

      document.head.appendChild(script)
    })
  }
}

// Export configuration
window.MapsConfig = MapsConfig
