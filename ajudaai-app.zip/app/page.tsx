"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Phone, Shield, Truck, Heart, AlertTriangle, Users, Settings } from "lucide-react"
import EmergencyMap from "./components/emergency-map"
import EmergencyContacts from "./components/emergency-contacts"
import CustomAlerts from "./components/custom-alerts"
import { useToast } from "@/hooks/use-toast"

interface Location {
  latitude: number
  longitude: number
  accuracy: number
}

interface EmergencyService {
  id: string
  name: string
  icon: any
  color: string
  phone: string
  description: string
}

const emergencyServices: EmergencyService[] = [
  {
    id: "samu",
    name: "SAMU",
    icon: Heart,
    color: "bg-red-500 hover:bg-red-600",
    phone: "192",
    description: "Serviço de Atendimento Móvel de Urgência",
  },
  {
    id: "bombeiros",
    name: "Bombeiros",
    icon: Shield,
    color: "bg-orange-500 hover:bg-orange-600",
    phone: "193",
    description: "Corpo de Bombeiros",
  },
  {
    id: "defesa-civil",
    name: "Defesa Civil",
    icon: Truck,
    color: "bg-blue-500 hover:bg-blue-600",
    phone: "199",
    description: "Defesa Civil",
  },
  {
    id: "policia",
    name: "Polícia",
    icon: Shield,
    color: "bg-gray-700 hover:bg-gray-800",
    phone: "190",
    description: "Polícia Militar",
  },
]

export default function AjudaAiApp() {
  const [currentLocation, setCurrentLocation] = useState<Location | null>(null)
  const [locationError, setLocationError] = useState<string>("")
  const [activeTab, setActiveTab] = useState<"map" | "contacts" | "alerts">("map")
  const [isEmergencyActive, setIsEmergencyActive] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    getCurrentLocation()
  }, [])

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      setLocationError("Geolocalização não é suportada neste navegador")
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCurrentLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        })
        setLocationError("")
      },
      (error) => {
        setLocationError("Erro ao obter localização: " + error.message)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      },
    )
  }

  const sendEmergencyAlert = async (service: EmergencyService) => {
    if (!currentLocation) {
      toast({
        title: "Erro",
        description: "Localização não disponível. Tentando obter localização...",
        variant: "destructive",
      })
      getCurrentLocation()
      return
    }

    setIsEmergencyActive(true)

    // Simular envio de alerta
    try {
      const alertData = {
        service: service.name,
        location: currentLocation,
        timestamp: new Date().toISOString(),
        address: `Lat: ${currentLocation.latitude.toFixed(6)}, Lng: ${currentLocation.longitude.toFixed(6)}`,
      }

      // Aqui seria feita a integração real com os serviços de emergência
      console.log("Enviando alerta:", alertData)

      toast({
        title: "Alerta Enviado!",
        description: `${service.name} foi notificado da sua localização. Aguarde o atendimento.`,
      })

      // Simular tempo de resposta
      setTimeout(() => {
        setIsEmergencyActive(false)
      }, 3000)
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao enviar alerta. Tente novamente.",
        variant: "destructive",
      })
      setIsEmergencyActive(false)
    }
  }

  const sendDiscreteAlert = () => {
    if (!currentLocation) {
      toast({
        title: "Erro",
        description: "Localização não disponível",
        variant: "destructive",
      })
      return
    }

    toast({
      title: "Alerta Discreto Enviado",
      description: "Seus contatos de emergência foram notificados discretamente.",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="bg-red-500 p-2 rounded-lg">
                <AlertTriangle className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">AjudaAí</h1>
                <p className="text-sm text-gray-600">Segurança e Auxílio Rápido</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {currentLocation && (
                <Badge variant="outline" className="text-green-600 border-green-600">
                  <MapPin className="h-3 w-3 mr-1" />
                  Localizado
                </Badge>
              )}
              {locationError && (
                <Badge variant="destructive">
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  Sem GPS
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab("map")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "map"
                  ? "border-red-500 text-red-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              <MapPin className="h-4 w-4 inline mr-2" />
              Emergência
            </button>
            <button
              onClick={() => setActiveTab("contacts")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "contacts"
                  ? "border-red-500 text-red-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              <Users className="h-4 w-4 inline mr-2" />
              Contatos
            </button>
            <button
              onClick={() => setActiveTab("alerts")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "alerts"
                  ? "border-red-500 text-red-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              <Settings className="h-4 w-4 inline mr-2" />
              Alertas
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "map" && (
          <div className="space-y-6">
            {/* Emergency Alert Section */}
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="text-red-800 flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2" />
                  Emergência Rápida
                </CardTitle>
                <CardDescription className="text-red-600">
                  Toque em um dos botões abaixo para enviar um alerta geolocalizado imediatamente
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {emergencyServices.map((service) => {
                    const IconComponent = service.icon
                    return (
                      <Button
                        key={service.id}
                        onClick={() => sendEmergencyAlert(service)}
                        disabled={isEmergencyActive}
                        className={`${service.color} text-white h-20 flex flex-col items-center justify-center space-y-2 transition-all duration-200 transform hover:scale-105`}
                      >
                        <IconComponent className="h-6 w-6" />
                        <span className="text-sm font-medium">{service.name}</span>
                        <span className="text-xs opacity-90">{service.phone}</span>
                      </Button>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Discrete Alert */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Phone className="h-5 w-5 mr-2" />
                  Alerta Discreto
                </CardTitle>
                <CardDescription>Para situações onde você precisa de ajuda mas não pode chamar atenção</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={sendDiscreteAlert}
                  variant="outline"
                  className="w-full h-16 text-lg border-2 border-gray-300 hover:border-gray-400 bg-transparent"
                >
                  Enviar Alerta Discreto aos Contatos
                </Button>
              </CardContent>
            </Card>

            {/* Map Component */}
            <EmergencyMap location={currentLocation} />
          </div>
        )}

        {activeTab === "contacts" && <EmergencyContacts />}
        {activeTab === "alerts" && <CustomAlerts />}
      </main>

      {/* Emergency Status Overlay */}
      {isEmergencyActive && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="mx-4 max-w-sm">
            <CardContent className="p-6 text-center">
              <div className="animate-pulse">
                <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Enviando Alerta...</h3>
                <p className="text-gray-600">Aguarde enquanto notificamos os serviços de emergência</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
