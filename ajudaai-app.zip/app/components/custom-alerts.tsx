"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Settings, Plus, AlertTriangle, MessageSquare, Clock, Trash2, Edit } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface CustomAlert {
  id: string
  name: string
  message: string
  isDiscrete: boolean
  autoLocation: boolean
  delay: number
  recipients: string[]
  trigger: string
}

const initialAlerts: CustomAlert[] = [
  {
    id: "1",
    name: "Assalto Discreto",
    message: "Preciso de ajuda urgente. Localização anexa.",
    isDiscrete: true,
    autoLocation: true,
    delay: 0,
    recipients: ["Família", "Amigos"],
    trigger: "manual",
  },
  {
    id: "2",
    name: "Acidente de Trânsito",
    message: "Sofri um acidente de trânsito. Preciso de ajuda.",
    isDiscrete: false,
    autoLocation: true,
    delay: 30,
    recipients: ["Família"],
    trigger: "manual",
  },
]

export default function CustomAlerts() {
  const [alerts, setAlerts] = useState<CustomAlert[]>(initialAlerts)
  const [isCreatingAlert, setIsCreatingAlert] = useState(false)
  const [newAlert, setNewAlert] = useState<Partial<CustomAlert>>({
    isDiscrete: false,
    autoLocation: true,
    delay: 0,
    recipients: [],
    trigger: "manual",
  })
  const { toast } = useToast()

  const createAlert = () => {
    if (!newAlert.name || !newAlert.message) {
      toast({
        title: "Erro",
        description: "Nome e mensagem são obrigatórios",
        variant: "destructive",
      })
      return
    }

    const alert: CustomAlert = {
      id: Date.now().toString(),
      name: newAlert.name,
      message: newAlert.message,
      isDiscrete: newAlert.isDiscrete || false,
      autoLocation: newAlert.autoLocation || true,
      delay: newAlert.delay || 0,
      recipients: newAlert.recipients || [],
      trigger: newAlert.trigger || "manual",
    }

    setAlerts([...alerts, alert])
    setNewAlert({
      isDiscrete: false,
      autoLocation: true,
      delay: 0,
      recipients: [],
      trigger: "manual",
    })
    setIsCreatingAlert(false)

    toast({
      title: "Alerta Criado",
      description: `Alerta "${alert.name}" foi criado com sucesso`,
    })
  }

  const removeAlert = (id: string) => {
    setAlerts(alerts.filter((a) => a.id !== id))
    toast({
      title: "Alerta Removido",
      description: "Alerta personalizado foi removido",
    })
  }

  const triggerAlert = (alert: CustomAlert) => {
    toast({
      title: "Alerta Ativado",
      description: `"${alert.name}" foi enviado para os destinatários selecionados`,
    })
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center">
                <Settings className="h-5 w-5 mr-2" />
                Alertas Personalizados
              </CardTitle>
              <CardDescription>Configure alertas específicos para diferentes situações</CardDescription>
            </div>
            <Dialog open={isCreatingAlert} onOpenChange={setIsCreatingAlert}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Criar Alerta
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Novo Alerta Personalizado</DialogTitle>
                  <DialogDescription>Configure um alerta específico para uma situação</DialogDescription>
                </DialogHeader>
                <div className="grid gap-6 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="alert-name">Nome do Alerta *</Label>
                    <Input
                      id="alert-name"
                      value={newAlert.name || ""}
                      onChange={(e) => setNewAlert({ ...newAlert, name: e.target.value })}
                      placeholder="Ex: Assalto, Acidente, Emergência Médica"
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="alert-message">Mensagem *</Label>
                    <Textarea
                      id="alert-message"
                      value={newAlert.message || ""}
                      onChange={(e) => setNewAlert({ ...newAlert, message: e.target.value })}
                      placeholder="Mensagem que será enviada aos contatos"
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="discrete"
                        checked={newAlert.isDiscrete}
                        onCheckedChange={(checked) => setNewAlert({ ...newAlert, isDiscrete: checked })}
                      />
                      <Label htmlFor="discrete">Alerta Discreto</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id="location"
                        checked={newAlert.autoLocation}
                        onCheckedChange={(checked) => setNewAlert({ ...newAlert, autoLocation: checked })}
                      />
                      <Label htmlFor="location">Incluir Localização</Label>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="delay">Atraso (segundos)</Label>
                    <Select onValueChange={(value) => setNewAlert({ ...newAlert, delay: Number.parseInt(value) })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Enviar imediatamente" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">Imediatamente</SelectItem>
                        <SelectItem value="30">30 segundos</SelectItem>
                        <SelectItem value="60">1 minuto</SelectItem>
                        <SelectItem value="300">5 minutos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label>Destinatários</Label>
                    <div className="flex flex-wrap gap-2">
                      {["Família", "Amigos", "Colegas", "Vizinhos"].map((group) => (
                        <Button
                          key={group}
                          variant={newAlert.recipients?.includes(group) ? "default" : "outline"}
                          size="sm"
                          onClick={() => {
                            const recipients = newAlert.recipients || []
                            if (recipients.includes(group)) {
                              setNewAlert({
                                ...newAlert,
                                recipients: recipients.filter((r) => r !== group),
                              })
                            } else {
                              setNewAlert({
                                ...newAlert,
                                recipients: [...recipients, group],
                              })
                            }
                          }}
                        >
                          {group}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreatingAlert(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={createAlert}>Criar Alerta</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {alerts.length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Nenhum alerta personalizado criado</p>
              <p className="text-sm text-gray-400 mt-2">Crie alertas específicos para diferentes situações</p>
            </div>
          ) : (
            <div className="space-y-4">
              {alerts.map((alert) => (
                <Card key={alert.id} className="border-l-4 border-l-blue-500">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="font-semibold">{alert.name}</h3>
                          {alert.isDiscrete && <Badge variant="secondary">Discreto</Badge>}
                          {alert.autoLocation && <Badge variant="outline">Com GPS</Badge>}
                          {alert.delay > 0 && (
                            <Badge variant="outline">
                              <Clock className="h-3 w-3 mr-1" />
                              {alert.delay}s
                            </Badge>
                          )}
                        </div>
                        <p className="text-gray-600 mb-3">{alert.message}</p>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-500">Destinatários:</span>
                          {alert.recipients.map((recipient) => (
                            <Badge key={recipient} variant="outline" className="text-xs">
                              {recipient}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <Button onClick={() => triggerAlert(alert)} className="bg-red-500 hover:bg-red-600">
                          <AlertTriangle className="h-4 w-4 mr-2" />
                          Ativar
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => removeAlert(alert.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Configurações Avançadas</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base">Vibração em Emergência</Label>
              <p className="text-sm text-gray-500">Vibrar o dispositivo ao enviar alertas</p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base">Som de Confirmação</Label>
              <p className="text-sm text-gray-500">Reproduzir som ao confirmar envio</p>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base">Modo Offline</Label>
              <p className="text-sm text-gray-500">Tentar enviar quando reconectar</p>
            </div>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
