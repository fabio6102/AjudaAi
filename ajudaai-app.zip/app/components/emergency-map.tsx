"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Navigation } from "lucide-react"

interface Location {
  latitude: number
  longitude: number
  accuracy: number
}

interface EmergencyMapProps {
  location: Location | null
}

export default function EmergencyMap({ location }: EmergencyMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (location && mapRef.current) {
      // Simular integração com Google Maps
      // Em produção, aqui seria carregado o Google Maps SDK
      console.log("Carregando mapa para:", location)
    }
  }, [location])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <MapPin className="h-5 w-5 mr-2" />
          Sua Localização
        </CardTitle>
        <CardDescription>Mapa em tempo real para auxiliar equipes de resgate</CardDescription>
      </CardHeader>
      <CardContent>
        <div
          ref={mapRef}
          className="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300"
        >
          {location ? (
            <div className="text-center">
              <Navigation className="h-12 w-12 text-blue-500 mx-auto mb-4" />
              <p className="text-lg font-semibold text-gray-700">Localização Ativa</p>
              <p className="text-sm text-gray-500 mt-2">Lat: {location.latitude.toFixed(6)}</p>
              <p className="text-sm text-gray-500">Lng: {location.longitude.toFixed(6)}</p>
              <p className="text-xs text-gray-400 mt-2">Precisão: ±{Math.round(location.accuracy)}m</p>
            </div>
          ) : (
            <div className="text-center">
              <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Obtendo localização...</p>
              <p className="text-sm text-gray-400 mt-2">Certifique-se de permitir acesso à localização</p>
            </div>
          )}
        </div>

        {location && (
          <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-center">
              <div className="bg-green-500 w-3 h-3 rounded-full mr-3 animate-pulse"></div>
              <p className="text-green-800 font-medium">GPS Ativo - Localização sendo compartilhada em tempo real</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
