"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Users, Plus, Phone, Mail, Trash2, Edit } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Contact {
  id: string
  name: string
  phone: string
  email: string
  relationship: string
  priority: "high" | "medium" | "low"
}

const initialContacts: Contact[] = [
  {
    id: "1",
    name: "Maria Silva",
    phone: "(24) 99999-1234",
    email: "maria@email.com",
    relationship: "Família",
    priority: "high",
  },
  {
    id: "2",
    name: "João Santos",
    phone: "(24) 98888-5678",
    email: "joao@email.com",
    relationship: "Amigo",
    priority: "medium",
  },
]

export default function EmergencyContacts() {
  const [contacts, setContacts] = useState<Contact[]>(initialContacts)
  const [isAddingContact, setIsAddingContact] = useState(false)
  const [editingContact, setEditingContact] = useState<Contact | null>(null)
  const [newContact, setNewContact] = useState<Partial<Contact>>({})
  const { toast } = useToast()

  const addContact = () => {
    if (!newContact.name || !newContact.phone) {
      toast({
        title: "Erro",
        description: "Nome e telefone são obrigatórios",
        variant: "destructive",
      })
      return
    }

    const contact: Contact = {
      id: Date.now().toString(),
      name: newContact.name,
      phone: newContact.phone,
      email: newContact.email || "",
      relationship: newContact.relationship || "Outro",
      priority: newContact.priority || "medium",
    }

    setContacts([...contacts, contact])
    setNewContact({})
    setIsAddingContact(false)

    toast({
      title: "Contato Adicionado",
      description: `${contact.name} foi adicionado aos seus contatos de emergência`,
    })
  }

  const removeContact = (id: string) => {
    setContacts(contacts.filter((c) => c.id !== id))
    toast({
      title: "Contato Removido",
      description: "Contato removido da lista de emergência",
    })
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "low":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case "high":
        return "Alta"
      case "medium":
        return "Média"
      case "low":
        return "Baixa"
      default:
        return "Média"
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Contatos de Emergência
              </CardTitle>
              <CardDescription>Pessoas que serão notificadas em caso de emergência</CardDescription>
            </div>
            <Dialog open={isAddingContact} onOpenChange={setIsAddingContact}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Contato
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Novo Contato de Emergência</DialogTitle>
                  <DialogDescription>Adicione uma pessoa para ser notificada em emergências</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Nome *</Label>
                    <Input
                      id="name"
                      value={newContact.name || ""}
                      onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                      placeholder="Nome completo"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone">Telefone *</Label>
                    <Input
                      id="phone"
                      value={newContact.phone || ""}
                      onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                      placeholder="(24) 99999-9999"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newContact.email || ""}
                      onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
                      placeholder="email@exemplo.com"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="relationship">Relacionamento</Label>
                    <Select onValueChange={(value) => setNewContact({ ...newContact, relationship: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o relacionamento" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Família">Família</SelectItem>
                        <SelectItem value="Amigo">Amigo</SelectItem>
                        <SelectItem value="Colega">Colega</SelectItem>
                        <SelectItem value="Vizinho">Vizinho</SelectItem>
                        <SelectItem value="Outro">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="priority">Prioridade</Label>
                    <Select
                      onValueChange={(value) =>
                        setNewContact({ ...newContact, priority: value as Contact["priority"] })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a prioridade" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">Alta</SelectItem>
                        <SelectItem value="medium">Média</SelectItem>
                        <SelectItem value="low">Baixa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddingContact(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={addContact}>Adicionar</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {contacts.length === 0 ? (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Nenhum contato de emergência cadastrado</p>
              <p className="text-sm text-gray-400 mt-2">
                Adicione pessoas que devem ser notificadas em caso de emergência
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {contacts.map((contact) => (
                <div key={contact.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="font-semibold">{contact.name}</h3>
                      <Badge className={getPriorityColor(contact.priority)}>{getPriorityLabel(contact.priority)}</Badge>
                      <Badge variant="outline">{contact.relationship}</Badge>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <Phone className="h-4 w-4 mr-1" />
                        {contact.phone}
                      </div>
                      {contact.email && (
                        <div className="flex items-center">
                          <Mail className="h-4 w-4 mr-1" />
                          {contact.email}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => removeContact(contact.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Como Funciona</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm text-gray-600">
            <div className="flex items-start space-x-3">
              <div className="bg-red-100 text-red-600 rounded-full p-1 mt-0.5">
                <span className="block w-2 h-2 bg-current rounded-full"></span>
              </div>
              <p>
                <strong>Alta Prioridade:</strong> Notificados imediatamente em qualquer emergência
              </p>
            </div>
            <div className="flex items-start space-x-3">
              <div className="bg-yellow-100 text-yellow-600 rounded-full p-1 mt-0.5">
                <span className="block w-2 h-2 bg-current rounded-full"></span>
              </div>
              <p>
                <strong>Média Prioridade:</strong> Notificados após 5 minutos se não houver resposta
              </p>
            </div>
            <div className="flex items-start space-x-3">
              <div className="bg-green-100 text-green-600 rounded-full p-1 mt-0.5">
                <span className="block w-2 h-2 bg-current rounded-full"></span>
              </div>
              <p>
                <strong>Baixa Prioridade:</strong> Notificados apenas em emergências graves
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
